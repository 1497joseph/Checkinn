/**
 * store/db.js — FarmTrack Data Store
 *
 * Isolated data layer using localStorage.
 * All reads/writes go through this module.
 * No UI logic here — pure data operations only.
 *
 * Schema:
 *   ft:users     → User[]
 *   ft:checkins  → CheckIn[]
 *   ft:session   → Session | null
 *
 * User:    { workNumber(PK), firstName, middleName, lastName, username, passwordHash, isAdmin, createdAt }
 * CheckIn: { id, username, date, farms[], arrivalTime|null, postedBy, lockedBy|null, createdAt }
 * Session: { username, loginAt }
 */

const Store = (() => {
  'use strict';

  const KEYS = Object.freeze({
    USERS:    'ft:users',
    CHECKINS: 'ft:checkins',
    SESSION:  'ft:session',
  });

  /* ── Serialization ── */
  const _load = key => {
    try { return JSON.parse(localStorage.getItem(key)) ?? []; }
    catch { return []; }
  };

  const _loadObj = key => {
    try { return JSON.parse(localStorage.getItem(key)) ?? null; }
    catch { return null; }
  };

  const _save = (key, data) => {
    try { localStorage.setItem(key, JSON.stringify(data)); return true; }
    catch { console.error(`[Store] Failed to save ${key}`); return false; }
  };

  /* ── PIN Hashing (FNV-1a 32-bit) ── */
  const hashPin = pin => {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < pin.length; i++) {
      h ^= pin.charCodeAt(i);
      h = Math.imul(h, 16777619) >>> 0;
    }
    return h.toString(16).padStart(8, '0');
  };

  /* ── Validation Helpers ── */
  const isValidPin    = p => /^\d{4}$/.test(p);
  const isValidWkNum  = w => /^[A-Za-z0-9\-_]{2,20}$/.test(w);
  const isValidUname  = u => /^[a-z0-9_]{2,20}$/.test(u);
  const normalizeUser = u => u.toLowerCase().trim();

  /* ── ID Generator ── */
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 5);

  /* ════════════════════════════════════
     SEED / INIT
  ════════════════════════════════════ */
  const init = () => {
    const users = _load(KEYS.USERS);
    if (!users.some(u => u.username === 'root')) {
      users.unshift({
        workNumber:   'ADMIN-001',
        firstName:    'System',
        middleName:   '',
        lastName:     'Administrator',
        username:     'root',
        passwordHash: hashPin('1234'),
        isAdmin:      true,
        createdAt:    new Date().toISOString(),
      });
      _save(KEYS.USERS, users);
    }
  };

  /* ════════════════════════════════════
     USER OPERATIONS
  ════════════════════════════════════ */
  const getUsers = () => _load(KEYS.USERS);

  const getUserByUsername = username =>
    getUsers().find(u => u.username === normalizeUser(username)) ?? null;

  const getUserByWorkNumber = wn =>
    getUsers().find(u => u.workNumber === wn) ?? null;

  const getFullName = user =>
    [user.firstName, user.middleName, user.lastName].filter(Boolean).join(' ');

  /**
   * @returns {{ ok: boolean, error?: string }}
   */
  const registerUser = ({ firstName, middleName, lastName, workNumber, username, pin }) => {
    const errs = [];
    if (!firstName?.trim()) errs.push('First name is required.');
    if (!lastName?.trim())  errs.push('Last name is required.');
    if (!workNumber?.trim()) errs.push('Work number is required.');
    else if (!isValidWkNum(workNumber.trim())) errs.push('Work number: 2–20 alphanumeric characters.');
    if (!username?.trim()) errs.push('Username is required.');
    else if (!isValidUname(username.trim().toLowerCase())) errs.push('Username: 2–20 lowercase letters, numbers, or underscores.');
    if (!isValidPin(pin)) errs.push('Password must be exactly 4 digits.');

    if (errs.length > 0) return { ok: false, error: errs[0] };

    const users = getUsers();
    if (users.some(u => u.workNumber === workNumber.trim())) return { ok: false, error: 'Work number already registered.' };
    if (users.some(u => u.username === normalizeUser(username))) return { ok: false, error: 'Username already taken.' };

    users.push({
      workNumber:   workNumber.trim(),
      firstName:    firstName.trim(),
      middleName:   (middleName || '').trim(),
      lastName:     lastName.trim(),
      username:     normalizeUser(username),
      passwordHash: hashPin(pin),
      isAdmin:      false,
      createdAt:    new Date().toISOString(),
    });
    _save(KEYS.USERS, users);
    return { ok: true };
  };

  /**
   * @returns {User|null}
   */
  const authenticate = (username, pin) => {
    const user = getUserByUsername(username);
    if (!user) return null;
    if (user.passwordHash !== hashPin(pin)) return null;
    return user;
  };

  /**
   * @returns {{ ok: boolean, error?: string }}
   */
  const updateUserCredentials = (workNumber, { newUsername, newPin }) => {
    const users = getUsers();
    const idx = users.findIndex(u => u.workNumber === workNumber);
    if (idx === -1) return { ok: false, error: 'User not found.' };

    if (newUsername) {
      const uname = normalizeUser(newUsername);
      if (!isValidUname(uname)) return { ok: false, error: 'Invalid username format.' };
      if (users.some((u, i) => i !== idx && u.username === uname)) return { ok: false, error: 'Username already taken.' };
      users[idx].username = uname;
    }
    if (newPin) {
      if (!isValidPin(newPin)) return { ok: false, error: 'Password must be exactly 4 digits.' };
      users[idx].passwordHash = hashPin(newPin);
    }
    _save(KEYS.USERS, users);
    return { ok: true };
  };

  /* ════════════════════════════════════
     SESSION OPERATIONS
  ════════════════════════════════════ */
  const setSession = username => {
    _save(KEYS.SESSION, { username: normalizeUser(username), loginAt: new Date().toISOString() });
  };
  const getSession = () => _loadObj(KEYS.SESSION);
  const clearSession = () => localStorage.removeItem(KEYS.SESSION);

  /* ════════════════════════════════════
     CHECK-IN OPERATIONS
  ════════════════════════════════════ */
  const getCheckins = () => _load(KEYS.CHECKINS);

  const getCheckin = (username, date) =>
    getCheckins().find(c => c.username === normalizeUser(username) && c.date === date) ?? null;

  const getCheckinsByRange = (from, to) =>
    getCheckins().filter(c => c.date >= from && c.date <= to);

  const getUserCheckinsByRange = (username, from, to) =>
    getCheckins().filter(c => c.username === normalizeUser(username) && c.date >= from && c.date <= to);

  /**
   * Upsert a check-in record.
   * @param {{ username, date, farms?, arrivalTime?, postedBy, lock? }} data
   * @returns {{ ok: boolean, action: 'created'|'updated' }}
   */
  const saveCheckin = ({ username, date, farms = [], arrivalTime, postedBy, lock = false }) => {
    const checkins = _load(KEYS.CHECKINS);
    const uname    = normalizeUser(username);
    const idx      = checkins.findIndex(c => c.username === uname && c.date === date);

    if (idx === -1) {
      checkins.push({
        id:          uid(),
        username:    uname,
        date,
        farms:       farms.map(f => f.trim()).filter(Boolean),
        arrivalTime: arrivalTime || null,
        postedBy:    normalizeUser(postedBy || username),
        lockedBy:    lock ? normalizeUser(postedBy || username) : null,
        createdAt:   new Date().toISOString(),
      });
      _save(KEYS.CHECKINS, checkins);
      return { ok: true, action: 'created' };
    }

    const ci = checkins[idx];

    // Merge farms (unique, case-insensitive)
    if (farms.length > 0) {
      const existing = new Set(ci.farms.map(f => f.toLowerCase()));
      farms.forEach(f => { if (f.trim() && !existing.has(f.trim().toLowerCase())) ci.farms.push(f.trim()); });
    }

    // Only update arrival if not locked OR if lock=false (admin override)
    if (arrivalTime) {
      if (!ci.lockedBy || !lock) {
        ci.arrivalTime = arrivalTime;
        ci.postedBy    = normalizeUser(postedBy || username);
        if (lock) ci.lockedBy = normalizeUser(postedBy || username);
      }
    }

    checkins[idx] = ci;
    _save(KEYS.CHECKINS, checkins);
    return { ok: true, action: 'updated' };
  };

  /**
   * Admin override — force-set arrival, clear lock.
   */
  const adminOverrideArrival = (username, date, arrivalTime) => {
    const checkins = _load(KEYS.CHECKINS);
    const idx = checkins.findIndex(c => c.username === normalizeUser(username) && c.date === date);
    if (idx === -1) return { ok: false, error: 'No check-in record found.' };
    checkins[idx].arrivalTime = arrivalTime;
    checkins[idx].lockedBy    = null; // admin cleared
    _save(KEYS.CHECKINS, checkins);
    return { ok: true };
  };

  /**
   * Delete a check-in record (admin only).
   */
  const revokeCheckin = (username, date) => {
    const checkins = _load(KEYS.CHECKINS);
    const filtered = checkins.filter(c => !(c.username === normalizeUser(username) && c.date === date));
    if (filtered.length === checkins.length) return { ok: false, error: 'No record found.' };
    _save(KEYS.CHECKINS, filtered);
    return { ok: true };
  };

  /**
   * Get all unique farm names for autocomplete.
   */
  const getAllFarms = () => {
    const all = new Set();
    getCheckins().forEach(c => c.farms.forEach(f => all.add(f)));
    return [...all].sort((a, b) => a.localeCompare(b));
  };

  /* ════════════════════════════════════
     EXPORTS
  ════════════════════════════════════ */
  return Object.freeze({
    init,
    // Users
    getUsers, getUserByUsername, getUserByWorkNumber,
    getFullName, registerUser, authenticate, updateUserCredentials,
    // Session
    setSession, getSession, clearSession,
    // Check-ins
    getCheckins, getCheckin, saveCheckin,
    getCheckinsByRange, getUserCheckinsByRange,
    adminOverrideArrival, revokeCheckin,
    getAllFarms,
    // Helpers exposed for services
    normalizeUser,
  });
})();
