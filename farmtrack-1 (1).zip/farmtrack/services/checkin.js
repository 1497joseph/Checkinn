/**
 * services/checkin.js — Check-In Business Logic Service
 *
 * All check-in operations, paste parsing, multi-arrival posting.
 * Pure business logic — no DOM, returns result objects.
 */

const CheckInService = (() => {
  'use strict';

  /* ════════════════════════════════════
     SELF CHECK-IN
  ════════════════════════════════════ */

  /**
   * Check in the current user for today.
   * @param {{ farm: string, arrivalTime?: string }} data
   * @returns {{ ok: boolean, error?: string, locked: boolean }}
   */
  const selfCheckIn = ({ farm, arrivalTime }) => {
    const user  = AuthService.getCurrentUser();
    if (!user) return { ok: false, error: 'Not authenticated.' };
    if (!farm?.trim()) return { ok: false, error: 'Farm name is required.' };

    const date    = TimeUtils.today();
    const existing = Store.getCheckin(user.username, date);
    const isLocked = !!(existing?.lockedBy && existing.lockedBy !== user.username);

    Store.saveCheckin({
      username:    user.username,
      date,
      farms:       [farm.trim()],
      arrivalTime: isLocked ? undefined : (arrivalTime || undefined),
      postedBy:    user.username,
      lock:        false,
    });

    return { ok: true, locked: isLocked };
  };

  /**
   * Get today's check-in for the current user.
   */
  const getTodayCheckIn = () => {
    const user = AuthService.getCurrentUser();
    if (!user) return null;
    return Store.getCheckin(user.username, TimeUtils.today());
  };

  /**
   * Check if current user's arrival is locked (posted by someone else).
   */
  const isArrivalLocked = () => {
    const ci = getTodayCheckIn();
    if (!ci) return false;
    const user = AuthService.getCurrentUser();
    return !!(ci.lockedBy && ci.lockedBy !== user.username);
  };

  /* ════════════════════════════════════
     MULTI-USER ARRIVAL POSTING
  ════════════════════════════════════ */

  /**
   * Post arrival time for multiple usernames.
   * Poster can be any logged-in user.
   * @param {{ usernames: string[], arrivalTime: string }} data
   * @returns {{ results: Array<{ username, status, reason? }> }}
   */
  const postMultiArrival = ({ usernames, arrivalTime }) => {
    const poster = AuthService.getCurrentUser();
    if (!poster) return { results: [] };

    const date    = TimeUtils.today();
    const results = [];

    for (const uname of usernames) {
      const clean = uname.toLowerCase().trim();
      if (!clean) continue;

      const targetUser = Store.getUserByUsername(clean);
      if (!targetUser) {
        results.push({ username: clean, status: 'not-found' });
        continue;
      }

      const existing  = Store.getCheckin(clean, date);
      const isSelf    = clean === poster.username;
      const isAlreadyLocked = !!(existing?.lockedBy && existing.lockedBy !== poster.username);

      // Only admin can override an existing lock posted by someone else
      if (isAlreadyLocked && !AuthService.isAdmin()) {
        results.push({ username: clean, status: 'locked', reason: `Locked by ${existing.lockedBy}` });
        continue;
      }

      // Ensure check-in record exists
      if (!existing) {
        Store.saveCheckin({ username: clean, date, farms: [], postedBy: poster.username, lock: false });
      }

      Store.saveCheckin({
        username:    clean,
        date,
        farms:       [],
        arrivalTime,
        postedBy:    poster.username,
        lock:        !isSelf, // lock for others, not self
      });

      results.push({ username: clean, status: existing ? 'updated' : 'created' });
    }

    return { results };
  };

  /* ════════════════════════════════════
     PASTE TEXT PARSING
  ════════════════════════════════════ */

  /**
   * Parse a collection message text and extract entries.
   * Returns { dayName, date, entries: [{farmer, farm, workers}] }
   */
  const parsePasteText = text => {
    if (!text?.trim()) return { ok: false, error: 'No text provided.' };

    const lines   = text.split('\n').map(l => l.trim()).filter(Boolean);
    const dayName = TimeUtils.extractDayName(lines[0] || '');
    const date    = dayName ? TimeUtils.mostRecentWeekday(dayName) : TimeUtils.today();

    const entries = [];

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      if (!line.includes('-')) continue;

      // Split at last '-' to separate farm/farmer part from workers
      const dashIdx = line.lastIndexOf('-');
      const left    = line.substring(0, dashIdx).trim();
      const right   = line.substring(dashIdx + 1).trim();
      if (!right) continue;

      // Workers (right side): split by '/' or ','
      const workers = right
        .split(/[\/,]/)
        .map(w => w.trim().toLowerCase())
        .filter(w => w.length >= 2);

      if (workers.length === 0) continue;

      // Clean left side: remove quantities (1T, 2.5T, 400kgs, BC, etc.)
      const leftClean = left
        .replace(/\b\d+(\.\d+)?\s*(T|KGS?|KG|LITRES?|L)\b/gi, '')
        .replace(/\bBC\b/gi, '')
        .trim();

      const words = leftClean.split(/\s+/).filter(Boolean);
      if (words.length === 0) continue;

      // Heuristic: first 2 words = farmer name, rest = farm
      let farmer, farm;
      if (words.length === 1) {
        farmer = words[0];
        farm   = words[0];
      } else if (words.length === 2) {
        farmer = words.join(' ');
        farm   = words[1]; // last word as farm proxy
      } else {
        farmer = words.slice(0, 2).join(' ');
        farm   = words.slice(2).join(' ');
      }

      entries.push({ farmer, farm, workers });
    }

    return { ok: true, dayName: dayName || 'today', date, entries };
  };

  /**
   * Check in workers from parsed paste entries.
   * @param {{ dayName, date, entries }} parsed
   * @returns {{ results: Array<{worker, farm, farmer, status}> }}
   */
  const applyParsedCheckIns = ({ date, entries }) => {
    const poster  = AuthService.getCurrentUser();
    const results = [];

    for (const entry of entries) {
      for (const workerUsername of entry.workers) {
        const user = Store.getUserByUsername(workerUsername);
        if (!user) {
          results.push({ worker: workerUsername, farm: entry.farm, farmer: entry.farmer, status: 'not-found' });
          continue;
        }
        const existing = Store.getCheckin(workerUsername, date);
        Store.saveCheckin({
          username:    workerUsername,
          date,
          farms:       [entry.farm],
          postedBy:    poster.username,
          lock:        false,
        });
        results.push({ worker: workerUsername, farm: entry.farm, farmer: entry.farmer, status: existing ? 'updated' : 'checked-in' });
      }
    }

    return { results };
  };

  /* ════════════════════════════════════
     ADMIN CHECK-IN OPERATIONS
  ════════════════════════════════════ */

  /**
   * Admin manual check-in for any user on any date.
   */
  const adminManualCheckIn = ({ username, date, farms, arrivalTime }) => {
    if (!AuthService.isAdmin()) return { ok: false, error: 'Access denied.' };
    if (!username || !date) return { ok: false, error: 'Username and date are required.' };

    const user = Store.getUserByUsername(username);
    if (!user) return { ok: false, error: 'User not found.' };

    Store.saveCheckin({
      username,
      date,
      farms: farms || [],
      arrivalTime: arrivalTime || undefined,
      postedBy:    AuthService.getCurrentUser().username,
      lock:        !!arrivalTime,
    });

    return { ok: true };
  };

  /**
   * Admin override arrival time for any user/date.
   */
  const adminEditArrival = ({ username, date, arrivalTime }) => {
    if (!AuthService.isAdmin()) return { ok: false, error: 'Access denied.' };
    return Store.adminOverrideArrival(username, date, arrivalTime);
  };

  /**
   * Admin revoke check-in for any user/date.
   */
  const adminRevokeCheckIn = ({ username, date }) => {
    if (!AuthService.isAdmin()) return { ok: false, error: 'Access denied.' };
    return Store.revokeCheckin(username, date);
  };

  /* ════════════════════════════════════
     QUERY HELPERS
  ════════════════════════════════════ */

  /** Get current user's check-ins for a date range */
  const getMyCheckIns = (from, to) => {
    const user = AuthService.getCurrentUser();
    if (!user) return [];
    return Store.getUserCheckinsByRange(user.username, from, to);
  };

  return Object.freeze({
    selfCheckIn, getTodayCheckIn, isArrivalLocked,
    postMultiArrival,
    parsePasteText, applyParsedCheckIns,
    adminManualCheckIn, adminEditArrival, adminRevokeCheckIn,
    getMyCheckIns,
  });
})();
