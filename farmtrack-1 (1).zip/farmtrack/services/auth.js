/**
 * services/auth.js — Authentication Service
 *
 * Bridges Store and UI for all auth operations.
 * No DOM manipulation here — returns data/results for pages to use.
 */

const AuthService = (() => {
  'use strict';

  /* Current in-memory user (set on login) */
  let _currentUser = null;

  /* ── Getters ── */
  const getCurrentUser = () => _currentUser;
  const isLoggedIn     = () => _currentUser !== null;
  const isAdmin        = () => _currentUser?.isAdmin === true;

  /* ── Login ── */
  const login = (username, pin) => {
    const user = Store.authenticate(username, pin);
    if (!user) return { ok: false, error: 'Invalid username or password.' };
    _currentUser = user;
    Store.setSession(user.username);
    return { ok: true, user };
  };

  /* ── Logout ── */
  const logout = () => {
    _currentUser = null;
    Store.clearSession();
  };

  /* ── Register ── */
  const register = (data) => {
    const result = Store.registerUser(data);
    if (!result.ok) return result;
    // Auto-login
    const user = Store.authenticate(data.username, data.pin);
    if (user) {
      _currentUser = user;
      Store.setSession(user.username);
    }
    return { ok: true, user };
  };

  /* ── Restore Session ── */
  const restoreSession = () => {
    const session = Store.getSession();
    if (!session) return null;
    const user = Store.getUserByUsername(session.username);
    if (!user) { Store.clearSession(); return null; }
    _currentUser = user;
    return user;
  };

  /* ── Update credentials ── */
  const updateCredentials = ({ newUsername, newPin }) => {
    if (!_currentUser) return { ok: false, error: 'Not logged in.' };
    const result = Store.updateUserCredentials(_currentUser.workNumber, { newUsername, newPin });
    if (result.ok) {
      // Refresh current user
      const updated = newUsername
        ? Store.getUserByUsername(newUsername)
        : Store.getUserByUsername(_currentUser.username);
      if (updated) {
        _currentUser = updated;
        Store.setSession(updated.username);
      }
    }
    return result;
  };

  return Object.freeze({
    getCurrentUser, isLoggedIn, isAdmin,
    login, logout, register,
    restoreSession, updateCredentials,
  });
})();
