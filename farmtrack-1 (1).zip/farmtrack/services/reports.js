/**
 * services/reports.js — Report Generation Engine
 *
 * Builds structured report data objects.
 * No DOM, no PDF — pure data transformation.
 * PDF rendering is in components/pdf.js.
 */

const ReportService = (() => {
  'use strict';

  /* ════════════════════════════════════
     CORE REPORT BUILDER
  ════════════════════════════════════ */

  /**
   * Build a detailed report for one user over a date range.
   * @returns {UserReport}
   *
   * UserReport: {
   *   username, workNumber, fullName,
   *   from, to,
   *   days: DayRecord[],
   *   totals: { days, hours, otMins, otHours }
   * }
   *
   * DayRecord: {
   *   date, dayName, farms[], arrivalTime,
   *   hoursWorked, otMins, isWorked
   * }
   */
  const buildUserReport = (username, from, to) => {
    const user = Store.getUserByUsername(username);
    if (!user) return null;

    const checkins   = Store.getUserCheckinsByRange(username, from, to);
    const checkinMap = Object.fromEntries(checkins.map(c => [c.date, c]));

    const days = [];
    for (const date of TimeUtils.datesBetween(from, to)) {
      const ci = checkinMap[date];
      if (!ci) continue; // only record worked days
      days.push({
        date,
        dayName:     TimeUtils.getDayName(date),
        farms:       ci.farms || [],
        arrivalTime: ci.arrivalTime || null,
        hoursWorked: TimeUtils.hoursWorked(ci.arrivalTime),
        otMins:      TimeUtils.overtimeMinutes(ci.arrivalTime),
        postedBy:    ci.postedBy || username,
        isWorked:    true,
      });
    }

    const totDays  = days.length;
    const totHours = days.reduce((s, d) => s + d.hoursWorked, 0);
    const totOT    = days.reduce((s, d) => s + d.otMins, 0);

    return {
      username,
      workNumber: user.workNumber,
      fullName:   Store.getFullName(user),
      from, to,
      days,
      totals: {
        days:    totDays,
        hours:   totHours,
        otMins:  totOT,
        otHours: totOT / 60,
      },
    };
  };

  /**
   * Build reports for ALL users over a date range.
   */
  const buildAllUsersReport = (from, to) => {
    const users = Store.getUsers();
    return users.map(u => buildUserReport(u.username, from, to)).filter(Boolean);
  };

  /* ════════════════════════════════════
     REPORT PRESETS
  ════════════════════════════════════ */

  /** Weekly report: Mon–Sat for the week containing `dateStr` */
  const weeklyReport = (username, dateStr) => {
    const { from, to } = TimeUtils.weekRange(dateStr);
    return buildUserReport(username, from, to);
  };

  const allUsersWeeklyReport = dateStr => {
    const { from, to } = TimeUtils.weekRange(dateStr);
    return buildAllUsersReport(from, to);
  };

  /** Mid-Month: 1st–15th of given month (YYYY-MM) */
  const midMonthReport = (username, monthStr) => {
    const [y, m] = monthStr.split('-');
    const from = `${y}-${m}-01`;
    const to   = `${y}-${m}-15`;
    return buildUserReport(username, from, to);
  };

  const allUsersMidMonthReport = monthStr => {
    const [y, m] = monthStr.split('-');
    const from = `${y}-${m}-01`;
    const to   = `${y}-${m}-15`;
    return buildAllUsersReport(from, to);
  };

  /** End-of-Month: 1st–last day of given month (YYYY-MM) */
  const endMonthReport = (username, monthStr) => {
    const [y, m] = monthStr.split('-').map(Number);
    const from = `${monthStr}-01`;
    const last = TimeUtils.lastDayOfMonth(y, m);
    const to   = `${monthStr}-${String(last).padStart(2,'0')}`;
    return buildUserReport(username, from, to);
  };

  const allUsersEndMonthReport = monthStr => {
    const [y, m] = monthStr.split('-').map(Number);
    const from = `${monthStr}-01`;
    const last = TimeUtils.lastDayOfMonth(y, m);
    const to   = `${monthStr}-${String(last).padStart(2,'0')}`;
    return buildAllUsersReport(from, to);
  };

  /** Custom range */
  const customReport = (username, from, to) => buildUserReport(username, from, to);
  const allUsersCustomReport = (from, to) => buildAllUsersReport(from, to);

  /* ════════════════════════════════════
     ANALYTICS
  ════════════════════════════════════ */

  /**
   * Get monthly analytics for charts.
   * @returns {{ labels, daysData, hoursData, otData, reports }}
   */
  const monthlyAnalytics = monthStr => {
    const [y, m] = monthStr.split('-').map(Number);
    const from = `${monthStr}-01`;
    const last = TimeUtils.lastDayOfMonth(y, m);
    const to   = `${monthStr}-${String(last).padStart(2,'0')}`;

    const reports = buildAllUsersReport(from, to);
    const labels  = reports.map(r => r.fullName.split(' ')[0]);

    return {
      labels,
      daysData:  reports.map(r => r.totals.days),
      hoursData: reports.map(r => parseFloat(r.totals.hours.toFixed(2))),
      otData:    reports.map(r => parseFloat(r.totals.otHours.toFixed(2))),
      reports,
    };
  };

  /**
   * Individual 6-week trend data.
   */
  const individualTrend = username => {
    const weeks = [];
    const base  = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(base);
      d.setDate(base.getDate() - i * 7);
      weeks.push(TimeUtils.weekRange(d));
    }
    return {
      labels:    weeks.map(w => w.from.slice(5)),
      hoursData: weeks.map(w => {
        const r = buildUserReport(username, w.from, w.to);
        return r ? parseFloat(r.totals.hours.toFixed(2)) : 0;
      }),
      otData: weeks.map(w => {
        const r = buildUserReport(username, w.from, w.to);
        return r ? parseFloat(r.totals.otHours.toFixed(2)) : 0;
      }),
    };
  };

  /* ════════════════════════════════════
     WORK SUGGESTIONS
  ════════════════════════════════════ */

  /**
   * Rank workers by fairness for a given date's week.
   * Scoring: fewer days worked = higher priority,
   *          less OT = secondary,
   *          alphabetical tiebreaker.
   */
  const workSuggestions = forDate => {
    const { from, to } = TimeUtils.weekRange(forDate);
    const users  = Store.getUsers();

    const scored = users.map(u => {
      const r = buildUserReport(u.username, from, to);
      return {
        username:   u.username,
        fullName:   Store.getFullName(u),
        workNumber: u.workNumber,
        daysWorked: r?.totals.days ?? 0,
        otHours:    r?.totals.otHours ?? 0,
        totalHours: r?.totals.hours ?? 0,
      };
    });

    const maxDays = Math.max(...scored.map(s => s.daysWorked), 1);
    const maxOT   = Math.max(...scored.map(s => s.otHours), 1);

    return scored
      .map(s => ({
        ...s,
        // Higher score = more recommended
        score: ((maxDays - s.daysWorked) * 10 + (maxOT - s.otHours) * 2),
      }))
      .sort((a, b) => b.score - a.score || a.fullName.localeCompare(b.fullName));
  };

  return Object.freeze({
    buildUserReport, buildAllUsersReport,
    weeklyReport, allUsersWeeklyReport,
    midMonthReport, allUsersMidMonthReport,
    endMonthReport, allUsersEndMonthReport,
    customReport, allUsersCustomReport,
    monthlyAnalytics, individualTrend,
    workSuggestions,
  });
})();
