/**
 * components/toast.js — Toast Notification System
 *
 * Self-contained, injectable toast component.
 * Usage: Toast.show('Message', 'success' | 'error' | 'warning' | 'info')
 */

const Toast = (() => {
  'use strict';

  let container = null;

  const _ensureContainer = () => {
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      container.setAttribute('role', 'alert');
      container.setAttribute('aria-live', 'polite');
      document.body.appendChild(container);
    }
    return container;
  };

  const ICONS = {
    success: '✓',
    error:   '✕',
    warning: '⚠',
    info:    'ℹ',
  };

  /**
   * @param {string} message
   * @param {'success'|'error'|'warning'|'info'} type
   * @param {number} duration ms
   */
  const show = (message, type = 'info', duration = 4000) => {
    const c    = _ensureContainer();
    const toast = document.createElement('div');
    toast.className = `toast toast--${type}`;
    toast.innerHTML = `
      <span class="toast__icon">${ICONS[type]}</span>
      <span>${message}</span>
    `;
    c.appendChild(toast);

    // Auto remove
    const remove = () => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(8px)';
      toast.style.transition = 'all 0.2s ease';
      setTimeout(() => { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 200);
    };
    setTimeout(remove, duration);
    toast.addEventListener('click', remove);
  };

  const success = (msg, dur) => show(msg, 'success', dur);
  const error   = (msg, dur) => show(msg, 'error', dur);
  const warning = (msg, dur) => show(msg, 'warning', dur);
  const info    = (msg, dur) => show(msg, 'info', dur);

  return Object.freeze({ show, success, error, warning, info });
})();
