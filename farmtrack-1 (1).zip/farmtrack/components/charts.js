/**
 * components/charts.js — Chart.js Analytics Component
 *
 * All chart rendering logic isolated here.
 * Operates on DOM elements by ID, called by page controllers.
 */

const Charts = (() => {
  'use strict';

  /* Track instances to destroy before re-render */
  const _instances = new Map();

  const _destroy = id => {
    if (_instances.has(id)) { _instances.get(id).destroy(); _instances.delete(id); }
  };

  const COLORS = {
    primary:  'rgba(18, 89, 195, 0.8)',
    primaryB: 'rgb(18, 89, 195)',
    green:    'rgba(0, 168, 68, 0.8)',
    greenB:   'rgb(0, 168, 68)',
    amber:    'rgba(255, 143, 0, 0.8)',
    amberB:   'rgb(255, 143, 0)',
    red:      'rgba(198, 40, 40, 0.8)',
    redB:     'rgb(198, 40, 40)',
    primaryFill: 'rgba(18, 89, 195, 0.1)',
    amberFill:   'rgba(255, 143, 0, 0.1)',
  };

  const DEFAULT_OPTIONS = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: 'rgba(11, 26, 46, 0.9)',
        titleColor: '#fff',
        bodyColor: '#9EAFCA',
        borderColor: 'rgba(255,255,255,0.1)',
        borderWidth: 1,
        cornerRadius: 10,
        padding: 12,
      },
    },
    scales: {
      x: { grid: { display: false }, ticks: { font: { family: 'DM Sans', weight: '600', size: 11 } } },
      y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { font: { family: 'DM Sans', size: 11 } } },
    },
  };

  /* ── Days Worked Bar Chart ── */
  const renderDaysChart = (canvasId, { labels, daysData }) => {
    _destroy(canvasId);
    const canvas = document.getElementById(canvasId);
    if (!canvas || !window.Chart) return;

    const chart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Days Worked',
          data: daysData,
          backgroundColor: COLORS.primary,
          borderColor: COLORS.primaryB,
          borderWidth: 2,
          borderRadius: 10,
          borderSkipped: false,
        }],
      },
      options: {
        ...DEFAULT_OPTIONS,
        plugins: {
          ...DEFAULT_OPTIONS.plugins,
          legend: { display: true },
          tooltip: { ...DEFAULT_OPTIONS.plugins.tooltip, callbacks: { label: ctx => ` ${ctx.raw} day(s)` } },
        },
        scales: { ...DEFAULT_OPTIONS.scales, y: { ...DEFAULT_OPTIONS.scales.y, ticks: { ...DEFAULT_OPTIONS.scales.y.ticks, stepSize: 1 } } },
      },
    });
    _instances.set(canvasId, chart);
  };

  /* ── Overtime Bar Chart ── */
  const renderOTChart = (canvasId, { labels, otData }) => {
    _destroy(canvasId);
    const canvas = document.getElementById(canvasId);
    if (!canvas || !window.Chart) return;

    const chart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Overtime Hours',
          data: otData,
          backgroundColor: COLORS.amber,
          borderColor: COLORS.amberB,
          borderWidth: 2,
          borderRadius: 10,
          borderSkipped: false,
        }],
      },
      options: {
        ...DEFAULT_OPTIONS,
        plugins: {
          ...DEFAULT_OPTIONS.plugins,
          legend: { display: true },
          tooltip: { ...DEFAULT_OPTIONS.plugins.tooltip, callbacks: { label: ctx => ` ${ctx.raw}h OT` } },
        },
      },
    });
    _instances.set(canvasId, chart);
  };

  /* ── Hours Bar Chart ── */
  const renderHoursChart = (canvasId, { labels, hoursData }) => {
    _destroy(canvasId);
    const canvas = document.getElementById(canvasId);
    if (!canvas || !window.Chart) return;

    const chart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Hours Worked',
          data: hoursData,
          backgroundColor: COLORS.green,
          borderColor: COLORS.greenB,
          borderWidth: 2,
          borderRadius: 10,
          borderSkipped: false,
        }],
      },
      options: {
        ...DEFAULT_OPTIONS,
        plugins: {
          ...DEFAULT_OPTIONS.plugins,
          legend: { display: true },
          tooltip: { ...DEFAULT_OPTIONS.plugins.tooltip, callbacks: { label: ctx => ` ${ctx.raw}h` } },
        },
      },
    });
    _instances.set(canvasId, chart);
  };

  /* ── Individual Trend Line Chart ── */
  const renderTrendChart = (canvasId, { labels, hoursData, otData }) => {
    _destroy(canvasId);
    const canvas = document.getElementById(canvasId);
    if (!canvas || !window.Chart) return;

    const chart = new Chart(canvas, {
      type: 'line',
      data: {
        labels,
        datasets: [
          {
            label: 'Hours Worked',
            data: hoursData,
            borderColor: COLORS.primaryB,
            backgroundColor: COLORS.primaryFill,
            fill: true,
            tension: 0.4,
            borderWidth: 2.5,
            pointRadius: 5,
            pointHoverRadius: 7,
            pointBackgroundColor: COLORS.primaryB,
          },
          {
            label: 'Overtime Hours',
            data: otData,
            borderColor: COLORS.amberB,
            backgroundColor: COLORS.amberFill,
            fill: true,
            tension: 0.4,
            borderWidth: 2.5,
            pointRadius: 5,
            pointHoverRadius: 7,
            pointBackgroundColor: COLORS.amberB,
          },
        ],
      },
      options: {
        ...DEFAULT_OPTIONS,
        plugins: {
          ...DEFAULT_OPTIONS.plugins,
          legend: {
            display: true,
            position: 'top',
            labels: { font: { family: 'DM Sans', weight: '600', size: 12 }, usePointStyle: true, padding: 20 },
          },
        },
      },
    });
    _instances.set(canvasId, chart);
  };

  /* ── Comparison Radar Chart ── */
  const renderComparisonChart = (canvasId, { labels, daysData, otData }) => {
    _destroy(canvasId);
    const canvas = document.getElementById(canvasId);
    if (!canvas || !window.Chart) return;

    const chart = new Chart(canvas, {
      type: 'radar',
      data: {
        labels,
        datasets: [
          { label: 'Days Worked', data: daysData, borderColor: COLORS.primaryB, backgroundColor: 'rgba(18,89,195,0.15)', pointBackgroundColor: COLORS.primaryB, borderWidth: 2 },
          { label: 'Overtime (h)', data: otData,  borderColor: COLORS.amberB,   backgroundColor: 'rgba(255,143,0,0.1)',   pointBackgroundColor: COLORS.amberB,   borderWidth: 2 },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: true, position: 'top', labels: { font: { family: 'DM Sans', weight: '700', size: 12 }, usePointStyle: true, padding: 20 } },
          tooltip: DEFAULT_OPTIONS.plugins.tooltip,
        },
        scales: {
          r: {
            beginAtZero: true,
            grid: { color: 'rgba(0,0,0,0.06)' },
            ticks: { font: { family: 'DM Sans', size: 10 }, backdropColor: 'transparent' },
            pointLabels: { font: { family: 'DM Sans', weight: '700', size: 11 } },
          },
        },
      },
    });
    _instances.set(canvasId, chart);
  };

  return Object.freeze({
    renderDaysChart,
    renderOTChart,
    renderHoursChart,
    renderTrendChart,
    renderComparisonChart,
  });
})();
