/**
 * components/report-renderer.js — Report HTML + PDF Renderer
 *
 * Accepts report data objects from ReportService and renders:
 *   - HTML table markup (for insertion into DOM)
 *   - PDF download (using jsPDF)
 */

const ReportRenderer = (() => {
  'use strict';

  /* ════════════════════════════════════
     HTML RENDERING
  ════════════════════════════════════ */

  /**
   * Render a single user's report as HTML string.
   */
  const renderUserReportHTML = (report, title) => {
    if (!report || report.days.length === 0) {
      return `<div class="empty-state">
        <div class="empty-state__icon">📭</div>
        <div class="empty-state__title">No Records Found</div>
        <div class="empty-state__text">No check-in records for this period.</div>
      </div>`;
    }

    const rows = report.days.map(d => {
      const otDisplay = d.otMins > 0
        ? `<span class="badge badge--warning">${TimeUtils.fmtMinutes(d.otMins)}</span>`
        : '<span style="color:var(--color-text-muted)">—</span>';
      return `<tr>
        <td><strong>${d.dayName}</strong></td>
        <td>${TimeUtils.formatDate(d.date, 'short')}</td>
        <td>${d.date}</td>
        <td>${d.farms.join(', ') || '—'}</td>
        <td style="font-family:var(--font-mono);font-weight:600">${d.arrivalTime || '—'}</td>
        <td>${d.hoursWorked.toFixed(2)}h</td>
        <td>${otDisplay}</td>
        <td><span class="badge badge--neutral" style="font-size:10px">${d.postedBy}</span></td>
      </tr>`;
    }).join('');

    const { totals } = report;

    return `
      <div class="card mt-6">
        <div class="card__header">
          <div class="card__title">
            <div class="icon" style="background:var(--color-primary-bg)">📋</div>
            <div>
              <div>${title || 'Report'}</div>
              <div style="font-size:var(--text-xs);color:var(--color-text-muted);font-weight:500">
                ${report.fullName} · #${report.workNumber} · ${TimeUtils.formatDate(report.from,'short')} – ${TimeUtils.formatDate(report.to,'short')}
              </div>
            </div>
          </div>
          <div class="flex gap-3">
            <button class="download-btn btn--sm" onclick="ReportRenderer.downloadPDF(${JSON.stringify(report).replace(/"/g,'&quot;')}, '${(title||'Report').replace(/'/g,"\\'")}')">
              ⬇ PDF
            </button>
          </div>
        </div>
        <div class="card__body">
          <div class="table-container">
            <table class="table">
              <thead>
                <tr>
                  <th>Day</th><th>Date</th><th>ISO Date</th><th>Farm(s)</th>
                  <th>Arrival</th><th>Hours</th><th>Overtime</th><th>Posted By</th>
                </tr>
              </thead>
              <tbody>${rows}</tbody>
            </table>
          </div>
          <div class="report-summary mt-6">
            <div class="report-summary__item">
              <div class="report-summary__value">${totals.days}</div>
              <div class="report-summary__label">Days Worked</div>
            </div>
            <div class="report-summary__item">
              <div class="report-summary__value">${totals.hours.toFixed(2)}h</div>
              <div class="report-summary__label">Total Hours</div>
            </div>
            <div class="report-summary__item">
              <div class="report-summary__value">${totals.otHours.toFixed(2)}h</div>
              <div class="report-summary__label">Overtime Hours</div>
            </div>
            <div class="report-summary__item">
              <div class="report-summary__value">${TimeUtils.fmtMinutes(totals.otMins)}</div>
              <div class="report-summary__label">OT (hh mm)</div>
            </div>
          </div>
        </div>
      </div>`;
  };

  /**
   * Render all users' summary table + collapsible details.
   */
  const renderAllUsersReportHTML = (reports, title, from, to) => {
    const valid = reports.filter(r => r && r.days.length > 0);
    if (valid.length === 0) {
      return `<div class="empty-state">
        <div class="empty-state__icon">📭</div>
        <div class="empty-state__title">No Records</div>
        <div class="empty-state__text">No check-in records found for this period.</div>
      </div>`;
    }

    const grandTotals = {
      days:  valid.reduce((s, r) => s + r.totals.days, 0),
      hours: valid.reduce((s, r) => s + r.totals.hours, 0),
      ot:    valid.reduce((s, r) => s + r.totals.otHours, 0),
    };

    const summaryRows = valid.map(r => `<tr>
      <td><strong>${r.fullName}</strong></td>
      <td>${r.username}</td>
      <td>${r.workNumber}</td>
      <td><span class="badge badge--primary">${r.totals.days}</span></td>
      <td>${r.totals.hours.toFixed(2)}h</td>
      <td>${r.totals.otMins > 0 ? `<span class="badge badge--warning">${r.totals.otHours.toFixed(2)}h</span>` : '—'}</td>
    </tr>`).join('');

    const details = valid
      .map(r => renderUserReportHTML(r, r.fullName))
      .join('');

    return `
      <div class="card mt-6">
        <div class="card__header">
          <div class="card__title">
            <div class="icon" style="background:var(--color-primary-bg)">📁</div>
            <div>
              <div>${title} — All Workers</div>
              <div style="font-size:var(--text-xs);color:var(--color-text-muted);font-weight:500">
                ${valid.length} workers · ${TimeUtils.formatDate(from,'short')} – ${TimeUtils.formatDate(to,'short')}
              </div>
            </div>
          </div>
          <button class="download-btn btn--sm" onclick="ReportRenderer.downloadAllPDF(${JSON.stringify(valid).replace(/"/g,'&quot;')}, '${(title||'').replace(/'/g,"\\'")}')">
            ⬇ Full PDF
          </button>
        </div>
        <div class="card__body">
          <div class="table-container">
            <table class="table">
              <thead><tr><th>Name</th><th>Username</th><th>Work#</th><th>Days</th><th>Hours</th><th>Overtime</th></tr></thead>
              <tbody>${summaryRows}</tbody>
              <tfoot>
                <tr>
                  <td colspan="3"><strong>GRAND TOTAL</strong></td>
                  <td><strong>${grandTotals.days}</strong></td>
                  <td><strong>${grandTotals.hours.toFixed(2)}h</strong></td>
                  <td><strong>${grandTotals.ot.toFixed(2)}h</strong></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
      <details class="mt-6" style="cursor:pointer">
        <summary style="font-weight:800;font-size:var(--text-md);padding:12px 0;list-style:none;display:flex;align-items:center;gap:8px">
          <span>▶</span> Individual Detailed Reports
        </summary>
        <div>${details}</div>
      </details>`;
  };

  /* ════════════════════════════════════
     PDF GENERATION
  ════════════════════════════════════ */

  const _pdfColors = {
    primary:  [18, 89, 195],
    success:  [0, 168, 68],
    light:    [240, 244, 252],
    border:   [220, 226, 234],
    text:     [30, 30, 40],
    muted:    [100, 110, 130],
    white:    [255, 255, 255],
  };

  const _drawHeader = (doc, title, subtitle) => {
    const W = 210, M = 14;
    doc.setFillColor(..._pdfColors.primary);
    doc.rect(0, 0, W, 32, 'F');
    // Accent line
    doc.setFillColor(..._pdfColors.success);
    doc.rect(0, 32, W, 3, 'F');

    doc.setTextColor(..._pdfColors.white);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.text('🌿 FarmTrack', M, 14);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(title, M, 22);
    doc.setFontSize(9);
    doc.text(subtitle, W - M, 22, { align: 'right' });
    doc.text(`Generated: ${new Date().toLocaleString()}`, W - M, 29, { align: 'right' });
  };

  const _drawTableHeader = (doc, y, cols, widths, startX = 14) => {
    doc.setFillColor(..._pdfColors.light);
    doc.rect(startX, y, 182, 9, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(..._pdfColors.muted);
    let x = startX + 3;
    cols.forEach((c, i) => { doc.text(c, x, y + 6); x += widths[i]; });
    return y + 10;
  };

  const downloadPDF = (report, title) => {
    if (!window.jspdf) { Toast.error('PDF library not loaded.'); return; }
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    const W = 210, M = 14;

    _drawHeader(doc,
      title,
      `${report.fullName} · ${report.workNumber} · ${report.from} → ${report.to}`
    );

    let y = 44;

    // User info block
    doc.setFillColor(248, 250, 252);
    doc.roundedRect(M, y, W - M*2, 18, 3, 3, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(..._pdfColors.text);
    doc.text(report.fullName, M + 4, y + 8);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(..._pdfColors.muted);
    doc.text(`Work #: ${report.workNumber}`, M + 4, y + 14);
    doc.text(`Period: ${report.from} → ${report.to}`, W/2, y + 14);
    y += 24;

    // Table
    const cols = ['Day', 'Date', 'Farm(s)', 'Arrival', 'Hours', 'Overtime'];
    const widths = [22, 24, 60, 22, 18, 24];
    y = _drawTableHeader(doc, y, cols, widths);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);

    report.days.forEach((d, idx) => {
      if (y > 268) { doc.addPage(); y = 20; y = _drawTableHeader(doc, y, cols, widths); }
      if (idx % 2 === 0) { doc.setFillColor(252, 253, 254); doc.rect(M, y - 1, W - M*2, 9, 'F'); }
      doc.setTextColor(..._pdfColors.text);
      let x = M + 3;
      const cells = [
        d.dayName.slice(0,3),
        d.date,
        (d.farms.join(', ') || '—').slice(0, 30),
        d.arrivalTime || '—',
        `${d.hoursWorked.toFixed(2)}h`,
        d.otMins > 0 ? TimeUtils.fmtMinutes(d.otMins) : '—',
      ];
      cells.forEach((cell, i) => {
        if (i === 5 && d.otMins > 0) doc.setTextColor(255, 143, 0);
        else doc.setTextColor(..._pdfColors.text);
        doc.text(cell, x, y + 5.5);
        x += widths[i];
      });
      doc.setDrawColor(..._pdfColors.border);
      doc.line(M, y + 8, W - M, y + 8);
      y += 9;
    });

    // Summary footer
    y += 4;
    doc.setFillColor(..._pdfColors.primary);
    doc.roundedRect(M, y, W - M*2, 16, 3, 3, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(..._pdfColors.white);
    doc.text(`Days: ${report.totals.days}`, M + 6, y + 10);
    doc.text(`Hours: ${report.totals.hours.toFixed(2)}h`, M + 40, y + 10);
    doc.text(`Overtime: ${report.totals.otHours.toFixed(2)}h (${TimeUtils.fmtMinutes(report.totals.otMins)})`, M + 85, y + 10);

    doc.save(`FarmTrack_${report.username}_${report.from}_${report.to}.pdf`);
    Toast.success('PDF downloaded!');
  };

  const downloadAllPDF = (reports, title) => {
    if (!window.jspdf) { Toast.error('PDF library not loaded.'); return; }
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    const W = 210, M = 14;

    const dateRange = reports.length > 0 ? `${reports[0].from} → ${reports[0].to}` : '';
    _drawHeader(doc, `${title} — All Workers`, dateRange);

    let y = 44;
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(..._pdfColors.text);
    doc.text('Summary', M, y); y += 8;

    const sumCols = ['Name', 'Username', 'Work#', 'Days', 'Hours', 'OT Hours'];
    const sumW    = [40, 28, 24, 16, 20, 20];
    y = _drawTableHeader(doc, y, sumCols, sumW);

    let gDays = 0, gHours = 0, gOT = 0;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    reports.forEach((r, idx) => {
      if (y > 268) { doc.addPage(); y = 20; y = _drawTableHeader(doc, y, sumCols, sumW); }
      if (idx % 2 === 0) { doc.setFillColor(252,253,254); doc.rect(M, y-1, W-M*2, 9,'F'); }
      doc.setTextColor(..._pdfColors.text);
      let x = M + 3;
      const cells = [r.fullName.slice(0,22), r.username, r.workNumber, String(r.totals.days), `${r.totals.hours.toFixed(2)}h`, `${r.totals.otHours.toFixed(2)}h`];
      cells.forEach((c, i) => { doc.text(c, x, y+5.5); x += sumW[i]; });
      doc.setDrawColor(..._pdfColors.border);
      doc.line(M, y+8, W-M, y+8);
      y += 9;
      gDays += r.totals.days; gHours += r.totals.hours; gOT += r.totals.otHours;
    });
    // Grand total row
    y += 2;
    doc.setFillColor(..._pdfColors.primary);
    doc.rect(M, y, W-M*2, 11, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(..._pdfColors.white);
    doc.text('TOTAL', M+3, y+7.5);
    doc.text(String(gDays), M+3+40+28+24, y+7.5);
    doc.text(`${gHours.toFixed(2)}h`, M+3+40+28+24+16, y+7.5);
    doc.text(`${gOT.toFixed(2)}h`, M+3+40+28+24+16+20, y+7.5);
    y += 16;

    // Per-user detail pages
    reports.forEach(r => {
      if (r.days.length === 0) return;
      doc.addPage();
      _drawHeader(doc, `${r.fullName} — ${title}`, `${r.workNumber} · ${r.from} → ${r.to}`);
      let dy = 44;
      const dCols = ['Day','Date','Farm(s)','Arrival','Hours','OT'];
      const dW    = [22,24,60,22,18,24];
      dy = _drawTableHeader(doc, dy, dCols, dW);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      r.days.forEach((d, idx) => {
        if (dy > 268) { doc.addPage(); dy = 20; dy = _drawTableHeader(doc, dy, dCols, dW); }
        if (idx%2===0) { doc.setFillColor(252,253,254); doc.rect(M, dy-1, W-M*2, 9,'F'); }
        let x = M+3;
        [d.dayName.slice(0,3), d.date, (d.farms.join(', ')||'—').slice(0,30), d.arrivalTime||'—', `${d.hoursWorked.toFixed(2)}h`, d.otMins>0?TimeUtils.fmtMinutes(d.otMins):'—']
          .forEach((c, i) => {
            doc.setTextColor(i===5&&d.otMins>0 ? 255 : _pdfColors.text[0], i===5&&d.otMins>0 ? 143 : _pdfColors.text[1], i===5&&d.otMins>0 ? 0 : _pdfColors.text[2]);
            doc.text(c, x, dy+5.5); x += dW[i];
          });
        doc.setDrawColor(..._pdfColors.border);
        doc.line(M, dy+8, W-M, dy+8);
        dy += 9;
      });
      dy += 4;
      doc.setFillColor(..._pdfColors.primary);
      doc.roundedRect(M, dy, W-M*2, 14, 3, 3, 'F');
      doc.setFont('helvetica','bold'); doc.setFontSize(10); doc.setTextColor(..._pdfColors.white);
      doc.text(`Days: ${r.totals.days}`, M+6, dy+9);
      doc.text(`Hours: ${r.totals.hours.toFixed(2)}h`, M+38, dy+9);
      doc.text(`OT: ${r.totals.otHours.toFixed(2)}h`, M+80, dy+9);
    });

    doc.save(`FarmTrack_AllUsers_${title.replace(/\s/g,'_')}.pdf`);
    Toast.success('PDF downloaded!');
  };

  return Object.freeze({
    renderUserReportHTML,
    renderAllUsersReportHTML,
    downloadPDF,
    downloadAllPDF,
  });
})();
