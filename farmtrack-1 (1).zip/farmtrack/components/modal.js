/**
 * components/modal.js — Reusable Modal Component
 *
 * Usage:
 *   Modal.open({ title, content, size? })
 *   Modal.close()
 */

const Modal = (() => {
  'use strict';

  let _backdrop = null;

  const _build = () => {
    if (document.getElementById('app-modal-backdrop')) return;

    _backdrop = document.createElement('div');
    _backdrop.id        = 'app-modal-backdrop';
    _backdrop.className = 'modal-backdrop hidden';
    _backdrop.innerHTML = `
      <div class="modal" id="app-modal" role="dialog" aria-modal="true">
        <div class="modal__header">
          <h3 class="modal__title" id="app-modal-title"></h3>
          <button class="modal__close" onclick="Modal.close()" aria-label="Close">✕</button>
        </div>
        <div class="modal__body" id="app-modal-body"></div>
        <div class="modal__footer hidden" id="app-modal-footer"></div>
      </div>
    `;
    document.body.appendChild(_backdrop);

    _backdrop.addEventListener('click', e => {
      if (e.target === _backdrop) close();
    });

    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') close();
    });
  };

  /**
   * @param {{ title: string, content: string|HTMLElement, size?: 'lg'|'xl', footer?: string }} opts
   */
  const open = ({ title, content, size, footer }) => {
    _build();
    const modal  = document.getElementById('app-modal');
    const titleEl  = document.getElementById('app-modal-title');
    const bodyEl   = document.getElementById('app-modal-body');
    const footerEl = document.getElementById('app-modal-footer');

    modal.className = `modal${size ? ' modal--' + size : ''}`;
    titleEl.textContent = title;

    if (typeof content === 'string') {
      bodyEl.innerHTML = content;
    } else {
      bodyEl.innerHTML = '';
      bodyEl.appendChild(content);
    }

    if (footer) {
      footerEl.innerHTML = footer;
      footerEl.classList.remove('hidden');
    } else {
      footerEl.classList.add('hidden');
    }

    _backdrop.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  };

  const close = () => {
    if (!_backdrop) return;
    _backdrop.classList.add('hidden');
    document.body.style.overflow = '';
  };

  return Object.freeze({ open, close });
})();
