/**
 * components/sidebar.js — Sidebar Navigation Component
 *
 * Renders the sidebar and handles active state, mobile toggle.
 * Calls Router.navigate() on nav-item clicks.
 */

const Sidebar = (() => {
  'use strict';

  const USER_NAV = [
    { id: 'dashboard',      icon: '🏠', label: 'Dashboard' },
    { id: 'checkin',        icon: '✅', label: 'Check-In' },
    { id: 'reports',        icon: '📊', label: 'My Reports' },
    { id: 'checkin-others', icon: '👥', label: 'Check-In Others' },
  ];

  const ADMIN_NAV = [
    { id: 'admin-dashboard',   icon: '📋', label: 'Admin Dashboard' },
    { id: 'admin-users',       icon: '👤', label: 'All Users' },
    { id: 'admin-checkin',     icon: '📝', label: 'Check-In Manager' },
    { id: 'admin-reports',     icon: '📁', label: 'All Reports' },
    { id: 'admin-charts',      icon: '📈', label: 'Charts & Analytics' },
    { id: 'admin-suggestions', icon: '💡', label: 'Work Suggestions' },
  ];

  const _buildNavItems = (items, section) =>
    `<div class="sidebar__nav-section">
       <div class="sidebar__nav-section-label">${section}</div>
     </div>` +
    items.map(item => `
      <button
        class="nav-item"
        data-route="${item.id}"
        onclick="Router.navigate('${item.id}')"
        aria-label="${item.label}"
      >
        <span class="nav-item__icon">${item.icon}</span>
        <span class="nav-item__text">${item.label}</span>
      </button>
    `).join('');

  /**
   * Render the complete sidebar for the current user.
   * @param {HTMLElement} el - The sidebar element
   */
  const render = el => {
    const user     = AuthService.getCurrentUser();
    if (!user) return;

    const initials = ((user.firstName[0] || '') + (user.lastName[0] || '')).toUpperCase();
    const fullName = Store.getFullName(user);
    const role     = user.isAdmin ? 'Administrator' : 'Farm Worker';

    let navHTML = _buildNavItems(USER_NAV, 'Main');
    if (user.isAdmin) navHTML += _buildNavItems(ADMIN_NAV, 'Admin Panel');

    el.innerHTML = `
      <div class="sidebar__brand">
        <div class="sidebar__brand-icon">🌿</div>
        <div class="sidebar__brand-text">
          <span class="sidebar__brand-name">FarmTrack</span>
          <span class="sidebar__brand-tagline">Work Management</span>
        </div>
      </div>
      <div class="sidebar__user">
        <div class="avatar">${initials}</div>
        <div class="sidebar__user-info">
          <div class="sidebar__user-name">${fullName}</div>
          <div class="sidebar__user-role">${role}</div>
        </div>
      </div>
      <nav class="sidebar__nav" aria-label="Main navigation">${navHTML}</nav>
      <div class="sidebar__footer">
        <button class="sidebar__logout" onclick="AuthService.logout(); Router.navigate('login');">
          <span>🚪</span>
          <span>Sign Out</span>
        </button>
      </div>
    `;
  };

  /**
   * Update active nav item based on current route.
   */
  const setActive = routeId => {
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('nav-item--active', el.dataset.route === routeId);
    });
  };

  /* Mobile toggle */
  let _open = false;
  const toggle = () => {
    _open = !_open;
    const sidebar  = document.getElementById('app-sidebar');
    const overlay  = document.getElementById('sidebar-overlay');
    sidebar?.classList.toggle('sidebar--open', _open);
    overlay?.classList.toggle('sidebar-overlay--visible', _open);
  };
  const close = () => {
    _open = false;
    document.getElementById('app-sidebar')?.classList.remove('sidebar--open');
    document.getElementById('sidebar-overlay')?.classList.remove('sidebar-overlay--visible');
  };

  return Object.freeze({ render, setActive, toggle, close });
})();
