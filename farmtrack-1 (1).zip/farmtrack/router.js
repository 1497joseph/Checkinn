/**
 * router.js — Single-Page Application Router
 *
 * Manages page rendering, guards, and navigation.
 * Each route maps to: { pageId, controller, requiresAuth, requiresAdmin }
 */

const Router = (() => {
  'use strict';

  /* ── Route Definitions ── */
  const ROUTES = {
    'login':              { pageId: 'page-login',              controller: LoginPage,            requiresAuth: false },
    'register':           { pageId: 'page-register',           controller: RegisterPage,         requiresAuth: false },
    'dashboard':          { pageId: 'page-dashboard',          controller: DashboardPage,        requiresAuth: true,  requiresAdmin: false },
    'checkin':            { pageId: 'page-checkin',            controller: CheckInPage,          requiresAuth: true,  requiresAdmin: false },
    'reports':            { pageId: 'page-reports',            controller: ReportsPage,          requiresAuth: true,  requiresAdmin: false },
    'checkin-others':     { pageId: 'page-checkin-others',     controller: CheckInOthersPage,    requiresAuth: true,  requiresAdmin: false },
    'admin-dashboard':    { pageId: 'page-admin-dashboard',    controller: AdminDashboardPage,   requiresAuth: true,  requiresAdmin: true  },
    'admin-users':        { pageId: 'page-admin-users',        controller: AdminUsersPage,       requiresAuth: true,  requiresAdmin: true  },
    'admin-checkin':      { pageId: 'page-admin-checkin',      controller: AdminCheckinPage,     requiresAuth: true,  requiresAdmin: true  },
    'admin-reports':      { pageId: 'page-admin-reports',      controller: AdminReportsPage,     requiresAuth: true,  requiresAdmin: true  },
    'admin-charts':       { pageId: 'page-admin-charts',       controller: AdminChartsPage,      requiresAuth: true,  requiresAdmin: true  },
    'admin-suggestions':  { pageId: 'page-admin-suggestions',  controller: AdminSuggestionsPage, requiresAuth: true,  requiresAdmin: true  },
  };

  let _currentRoute = null;
  let _currentController = null;

  /* ── Build the app shell DOM ── */
  const _ensureAppShell = () => {
    if (document.getElementById('app-shell')) return;

    const shell = document.createElement('div');
    shell.id        = 'app-shell';
    shell.className = 'app-shell hidden';
    shell.innerHTML = `
      <!-- Mobile overlay -->
      <div id="sidebar-overlay" class="sidebar-overlay" onclick="Sidebar.close()"></div>

      <!-- Sidebar -->
      <aside class="sidebar" id="app-sidebar" aria-label="Main navigation"></aside>

      <!-- Main area -->
      <div class="main" id="app-main">
        <!-- Mobile topbar -->
        <header class="topbar" aria-label="Top navigation">
          <button class="topbar__menu-btn" onclick="Sidebar.toggle()" aria-label="Toggle menu">☰</button>
          <span class="topbar__brand">🌿 FarmTrack</span>
          <span class="topbar__user" id="topbar-username"></span>
        </header>
        <!-- Page content -->
        <div class="content" id="app-content" role="main"></div>
      </div>
    `;
    document.body.appendChild(shell);
  };

  /* ── Ensure individual page containers exist ── */
  const _ensurePageContainers = () => {
    const content = document.getElementById('app-content');
    if (!content) return;

    Object.values(ROUTES).forEach(({ pageId }) => {
      if (!document.getElementById(pageId)) {
        const el = document.createElement('div');
        el.id        = pageId;
        el.className = 'page';
        content.appendChild(el);
      }
    });
  };

  /* ── Separate auth pages from app pages ── */
  const AUTH_PAGE_IDS = ['page-login', 'page-register'];

  const _ensureAuthContainers = () => {
    AUTH_PAGE_IDS.forEach(pageId => {
      if (!document.getElementById(pageId)) {
        const el = document.createElement('div');
        el.id        = pageId;
        el.className = 'page';
        document.body.appendChild(el);
      }
    });
  };

  /* ── Navigate to a route ── */
  const navigate = routeId => {
    const route = ROUTES[routeId];
    if (!route) { console.error(`[Router] Unknown route: ${routeId}`); return; }

    /* Auth guard */
    if (route.requiresAuth && !AuthService.isLoggedIn()) {
      navigate('login');
      return;
    }
    if (route.requiresAdmin && !AuthService.isAdmin()) {
      navigate('dashboard');
      return;
    }
    /* Redirect logged-in user away from auth pages */
    if (!route.requiresAuth && AuthService.isLoggedIn()) {
      navigate(AuthService.isAdmin() ? 'admin-dashboard' : 'dashboard');
      return;
    }

    /* Destroy previous controller if it has a destroy method */
    if (_currentController?.destroy) _currentController.destroy();

    const isAuthRoute = !route.requiresAuth;

    /* Toggle app shell visibility */
    const shell = document.getElementById('app-shell');
    if (shell) shell.classList.toggle('hidden', isAuthRoute);

    /* Deactivate all pages */
    document.querySelectorAll('.page--active').forEach(p => p.classList.remove('page--active'));

    /* Render the route's page */
    const el = document.getElementById(route.pageId);
    if (!el) { console.error(`[Router] Page container not found: ${route.pageId}`); return; }

    route.controller.render(el);
    el.classList.add('page--active');

    /* Update sidebar if inside app */
    if (!isAuthRoute) {
      const sidebar = document.getElementById('app-sidebar');
      if (sidebar) Sidebar.render(sidebar);
      Sidebar.setActive(routeId);
      Sidebar.close();

      const topUser = document.getElementById('topbar-username');
      if (topUser) topUser.textContent = '@' + AuthService.getCurrentUser()?.username;
    }

    _currentRoute      = routeId;
    _currentController = route.controller;

    /* Update URL hash for bookmarking */
    if (history.replaceState) {
      history.replaceState(null, '', `#${routeId}`);
    }
  };

  /* ── Bootstrap ── */
  const init = () => {
    Store.init();
    _ensureAuthContainers();
    _ensureAppShell();
    _ensurePageContainers();

    /* Restore session */
    const user = AuthService.restoreSession();
    if (user) {
      navigate(user.isAdmin ? 'admin-dashboard' : 'dashboard');
    } else {
      /* Check hash */
      const hash = window.location.hash.slice(1);
      navigate(hash === 'register' ? 'register' : 'login');
    }

    /* Handle browser back/forward */
    window.addEventListener('popstate', () => {
      const hash = window.location.hash.slice(1);
      if (hash && ROUTES[hash]) navigate(hash);
    });
  };

  return Object.freeze({ navigate, init });
})();
