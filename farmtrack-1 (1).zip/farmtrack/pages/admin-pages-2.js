/**
 * pages/admin-charts.js — Admin Analytics Charts Page
 */
const AdminChartsPage = (() => {
  'use strict';

  const render = el => {
    const users = Store.getUsers();
    const userOpts = users.map(u =>
      `<option value="${u.username}">${Store.getFullName(u)}</option>`
    ).join('');
    const monthOpts = _buildMonthOptions();

    el.innerHTML = `
      <div class="section-header">
        <div class="section-header__left">
          <div class="section-header__title">Charts & Analytics</div>
          <div class="section-header__sub">Visual comparisons of worker performance</div>
        </div>
      </div>

      <!-- Controls -->
      <div class="card mb-6">
        <div class="card__body" style="display:flex;gap:16px;align-items:flex-end;flex-wrap:wrap">
          <div class="form-field" style="flex:1;min-width:160px">
            <label class="form-label">Month</label>
            <select class="form-select" id="ch-month">${monthOpts}</select>
          </div>
          <button class="btn btn--primary" onclick="AdminChartsPage.refresh()">Refresh Charts</button>
        </div>
      </div>

      <!-- Group charts -->
      <div class="grid-2 mb-6">
        <div class="card">
          <div class="card__header">
            <div class="card__title">
              <div class="icon" style="background:var(--color-primary-bg)">📊</div>
              Days Worked
            </div>
          </div>
          <div class="card__body" style="height:260px;position:relative">
            <canvas id="ch-days"></canvas>
          </div>
        </div>
        <div class="card">
          <div class="card__header">
            <div class="card__title">
              <div class="icon" style="background:var(--clr-amber-50)">⏰</div>
              Overtime Hours
            </div>
          </div>
          <div class="card__body" style="height:260px;position:relative">
            <canvas id="ch-ot"></canvas>
          </div>
        </div>
      </div>

      <!-- Hours comparison -->
      <div class="card mb-6">
        <div class="card__header">
          <div class="card__title">
            <div class="icon" style="background:var(--clr-green-50)">📈</div>
            Total Hours Worked
          </div>
        </div>
        <div class="card__body" style="height:260px;position:relative">
          <canvas id="ch-hours"></canvas>
        </div>
      </div>

      <!-- Radar comparison -->
      <div class="card mb-6">
        <div class="card__header">
          <div class="card__title">
            <div class="icon" style="background:var(--clr-primary-50)">🕸</div>
            Team Comparison Radar
          </div>
        </div>
        <div class="card__body" style="height:340px;position:relative">
          <canvas id="ch-radar"></canvas>
        </div>
      </div>

      <!-- Individual trend -->
      <div class="card">
        <div class="card__header">
          <div class="card__title">
            <div class="icon" style="background:var(--clr-primary-50)">📉</div>
            Individual 6-Week Trend
          </div>
        </div>
        <div class="card__body">
          <div class="form-field" style="max-width:300px;margin-bottom:20px">
            <label class="form-label">Select Worker</label>
            <select class="form-select" id="ch-ind-user" onchange="AdminChartsPage.renderIndividual()">
              ${userOpts}
            </select>
          </div>
          <div style="height:280px;position:relative">
            <canvas id="ch-individual"></canvas>
          </div>
        </div>
      </div>`;

    // Render charts after DOM is ready
    setTimeout(() => AdminChartsPage.refresh(), 60);
  };

  const _buildMonthOptions = () => {
    const opts = [];
    const now  = new Date();
    for (let i = 0; i < 12; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const val = TimeUtils.toMonthStr(d);
      const lbl = d.toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
      opts.push(`<option value="${val}" ${i===0?'selected':''}>${lbl}</option>`);
    }
    return opts.join('');
  };

  const refresh = () => {
    const month = document.getElementById('ch-month')?.value || TimeUtils.toMonthStr();
    const data  = ReportService.monthlyAnalytics(month);
    Charts.renderDaysChart('ch-days', data);
    Charts.renderOTChart('ch-ot', data);
    Charts.renderHoursChart('ch-hours', data);
    Charts.renderComparisonChart('ch-radar', data);
    renderIndividual();
  };

  const renderIndividual = () => {
    const username = document.getElementById('ch-ind-user')?.value;
    if (!username) return;
    const trend = ReportService.individualTrend(username);
    Charts.renderTrendChart('ch-individual', trend);
  };

  return Object.freeze({ render, refresh, renderIndividual });
})();


/**
 * pages/admin-suggestions.js — Work Suggestions Page
 */
const AdminSuggestionsPage = (() => {
  'use strict';

  const render = el => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = TimeUtils.toDateStr(tomorrow);

    el.innerHTML = `
      <div class="section-header">
        <div class="section-header__left">
          <div class="section-header__title">Work Suggestions</div>
          <div class="section-header__sub">
            Fairness-based ranking — who should work tomorrow?
          </div>
        </div>
      </div>

      <div class="card mb-6">
        <div class="card__header">
          <div class="card__title">
            <div class="icon" style="background:var(--clr-amber-50)">⚖️</div>
            Fairness Algorithm
          </div>
        </div>
        <div class="card__body">
          <div class="alert alert--info mb-4">
            <span class="alert__icon">ℹ</span>
            <div class="alert__body">
              <div class="alert__title">How suggestions work</div>
              Workers are ranked by: (1) Fewest days worked this week — primary,
              (2) Lowest overtime hours — secondary, (3) Alphabetical tiebreaker.
              Higher score = more recommended for the next work day.
            </div>
          </div>
          <div class="form-row" style="align-items:flex-end">
            <div class="form-field" style="flex:1">
              <label class="form-label">Suggest for Date</label>
              <input class="form-input" type="date" id="sg-date" value="${tomorrowStr}" />
            </div>
            <button class="btn btn--primary" onclick="AdminSuggestionsPage.generate()">
              💡 Get Suggestions
            </button>
          </div>
        </div>
      </div>

      <div id="sg-result"></div>`;
  };

  const generate = () => {
    const date = document.getElementById('sg-date')?.value;
    if (!date) { Toast.warning('Please select a date.'); return; }

    const suggestions = ReportService.workSuggestions(date);
    const dateLabel   = new Date(date+'T12:00:00').toLocaleDateString('en-US',
      { weekday:'long', day:'numeric', month:'long', year:'numeric' });

    const cards = suggestions.map((s, i) => {
      let rankClass = '';
      if (i === 0) rankClass = 'suggestion-rank--top';
      else if (i === 1) rankClass = 'suggestion-rank--second';
      else if (i === 2) rankClass = 'suggestion-rank--third';
      return `
        <div class="suggestion-card">
          <div class="suggestion-rank ${rankClass}">${i+1}</div>
          <div class="suggestion-info">
            <div class="suggestion-name">${s.fullName}</div>
            <div class="suggestion-detail">
              @${s.username} · #${s.workNumber}
              &nbsp;·&nbsp; Days this week: <strong>${s.daysWorked}</strong>
              &nbsp;·&nbsp; Overtime: <strong>${s.otHours.toFixed(1)}h</strong>
              &nbsp;·&nbsp; Total hours: <strong>${s.totalHours.toFixed(1)}h</strong>
            </div>
          </div>
          <div class="suggestion-score">${s.score.toFixed(0)}pts</div>
        </div>`;
    }).join('');

    document.getElementById('sg-result').innerHTML = `
      <div class="card">
        <div class="card__header">
          <div class="card__title">
            <div class="icon" style="background:var(--clr-amber-50)">💡</div>
            Suggestions for ${dateLabel}
          </div>
          <span class="badge badge--primary">${suggestions.length} workers ranked</span>
        </div>
        <div class="card__body">
          <div style="display:flex;flex-direction:column;gap:var(--sp-3)">
            ${cards}
          </div>
          <div class="alert alert--info mt-6">
            <span class="alert__icon">💡</span>
            <span>Top-ranked workers have worked fewest days and accumulated least overtime this week — ensuring fair distribution of work.</span>
          </div>
        </div>
      </div>`;
  };

  return Object.freeze({ render, generate });
})();
