/**
 * pages/checkin-others.js — Check-In Others Page Controller
 */

const CheckInOthersPage = (() => {
  'use strict';

  const render = el => {
    el.innerHTML = `
      <div class="section-header">
        <div class="section-header__left">
          <div class="section-header__title">Check-In Others</div>
          <div class="section-header__sub">Post arrivals or check in teammates via paste or manual entry</div>
        </div>
      </div>

      <div class="grid-2">
        <!-- Paste text -->
        <div class="card">
          <div class="card__header">
            <div class="card__title">
              <div class="icon" style="background:var(--color-primary-bg)">📋</div>
              Paste Collection Text
            </div>
          </div>
          <div class="card__body">
            <div class="alert alert--info mb-4">
              <span class="alert__icon">ℹ</span>
              <div class="alert__body">
                <div class="alert__title">Format Example</div>
                Paste the day's collection message. Workers after the dash (–) will be automatically checked in.
                <br><code style="font-size:11px;display:block;margin-top:6px">Wednesday collection<br>Benard Gacoki kiamiciri 1T-dan<br>Joseph Rwika 2.5T-anthony/felix</code>
              </div>
            </div>
            <div class="form-field">
              <label class="form-label">Collection Message</label>
              <textarea class="form-textarea" id="co-paste" rows="10" placeholder="Paste collection text here…"></textarea>
            </div>
            <div id="co-parse-preview" class="hidden mt-4"></div>
            <div style="display:flex;gap:var(--sp-3);margin-top:var(--sp-4)">
              <button class="btn btn--ghost" onclick="CheckInOthersPage.preview()">👁 Preview</button>
              <button class="btn btn--primary" onclick="CheckInOthersPage.parsePaste()">✅ Parse & Check-In</button>
            </div>
            <div id="co-paste-result" class="mt-4"></div>
          </div>
        </div>

        <!-- Multi-arrival + Manual -->
        <div style="display:flex;flex-direction:column;gap:var(--sp-6)">
          <!-- Multi arrival -->
          <div class="card">
            <div class="card__header">
              <div class="card__title">
                <div class="icon" style="background:var(--clr-green-50)">⏰</div>
                Post Arrival for Multiple Users
              </div>
            </div>
            <div class="card__body">
              <div class="alert alert--info mb-4">
                <span class="alert__icon">ℹ</span>
                <span>Format: <code>joseph/dan/felix</code> or <code>joseph, dan, felix</code></span>
              </div>
              <div class="form-group">
                <div class="form-field">
                  <label class="form-label form-label--required">Usernames (/ or , separated)</label>
                  <input class="form-input" type="text" id="multi-users" placeholder="e.g. joseph/dan/felix" />
                </div>
                <div class="form-field">
                  <label class="form-label form-label--required">Arrival Time</label>
                  <div class="time-group">
                    <button type="button" class="btn btn--ghost btn--sm" onclick="CheckInOthersPage.useNow()">📍 Now</button>
                    <span class="divider">or</span>
                    <input class="form-input" type="time" id="multi-time" style="flex:1" />
                  </div>
                </div>
                <button class="btn btn--primary btn--block" onclick="CheckInOthersPage.postMulti()">Post Arrival</button>
              </div>
              <div id="multi-result" class="mt-4"></div>
            </div>
          </div>

          <!-- Today's posted arrivals -->
          <div class="card">
            <div class="card__header">
              <div class="card__title"><div class="icon" style="background:var(--clr-amber-50)">📍</div>Today's Activity</div>
            </div>
            <div class="card__body" id="co-today-activity">
              ${_renderTodayActivity()}
            </div>
          </div>
        </div>
      </div>
    `;
  };

  const _renderTodayActivity = () => {
    const today = TimeUtils.today();
    const all   = Store.getCheckinsByRange(today, today);
    if (all.length === 0) {
      return `<div class="empty-state"><div class="empty-state__icon">📭</div><div class="empty-state__title">No Activity</div><div class="empty-state__text">No check-ins today yet.</div></div>`;
    }
    return all.map(ci => {
      const user = Store.getUserByUsername(ci.username);
      const name = user ? Store.getFullName(user) : ci.username;
      const initials = user ? ((user.firstName[0]||'') + (user.lastName[0]||'')).toUpperCase() : '??';
      return `
        <div class="timeline-item">
          <div class="avatar avatar--sm">${initials}</div>
          <div class="timeline-content">
            <div class="timeline-title">${name}</div>
            <div class="timeline-sub">🌾 ${ci.farms.join(', ') || '—'}</div>
          </div>
          <div style="text-align:right">
            <div class="timeline-meta">${ci.arrivalTime || 'No arrival'}</div>
            ${ci.lockedBy ? `<div style="font-size:10px;color:var(--color-text-muted)">by ${ci.lockedBy}</div>` : ''}
          </div>
        </div>`;
    }).join('');
  };

  const useNow = () => {
    const inp = document.getElementById('multi-time');
    if (inp) inp.value = TimeUtils.nowTime();
  };

  const preview = () => {
    const text = document.getElementById('co-paste')?.value || '';
    const parsed = CheckInService.parsePasteText(text);
    const out = document.getElementById('co-parse-preview');

    if (!parsed.ok) {
      out.innerHTML = `<div class="alert alert--danger"><span class="alert__icon">✕</span><span>${parsed.error}</span></div>`;
    } else {
      out.innerHTML = `
        <div class="alert alert--info">
          <span class="alert__icon">ℹ</span>
          <div class="alert__body">
            <div class="alert__title">Parsed: ${parsed.dayName} (${parsed.date})</div>
            ${parsed.entries.length} entries found: ${parsed.entries.map(e => `<strong>${e.workers.join('/')}</strong> → ${e.farm}`).join(', ')}
          </div>
        </div>`;
    }
    out.classList.remove('hidden');
  };

  const parsePaste = () => {
    const text   = document.getElementById('co-paste')?.value || '';
    const out    = document.getElementById('co-paste-result');
    const parsed = CheckInService.parsePasteText(text);

    if (!parsed.ok) {
      out.innerHTML = `<div class="alert alert--danger"><span class="alert__icon">✕</span><span>${parsed.error}</span></div>`;
      return;
    }

    const { results } = CheckInService.applyParsedCheckIns(parsed);

    const rows = results.map(r => `<tr>
      <td><strong>${r.worker}</strong></td>
      <td>${r.farm}</td>
      <td>${r.farmer || '—'}</td>
      <td>${r.status === 'not-found'
        ? '<span class="badge badge--danger">Not Found</span>'
        : r.status === 'updated'
        ? '<span class="badge badge--warning">Updated</span>'
        : '<span class="badge badge--success">Checked In</span>'
      }</td>
    </tr>`).join('');

    out.innerHTML = `
      <div class="alert alert--success mb-4">
        <span class="alert__icon">✓</span>
        <span>Processed ${results.length} entries for <strong>${parsed.dayName}</strong> (${parsed.date})</span>
      </div>
      <div class="table-container">
        <table class="table table--compact">
          <thead><tr><th>Worker</th><th>Farm</th><th>Farmer</th><th>Status</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>`;

    // Refresh today activity
    const act = document.getElementById('co-today-activity');
    if (act) act.innerHTML = _renderTodayActivity();
  };

  const postMulti = () => {
    const usersRaw = document.getElementById('multi-users')?.value || '';
    const time     = document.getElementById('multi-time')?.value || '';
    const out      = document.getElementById('multi-result');

    if (!time) { out.innerHTML = `<div class="alert alert--danger"><span>⚠</span> Please set an arrival time.</div>`; return; }
    if (!usersRaw.trim()) { out.innerHTML = `<div class="alert alert--danger"><span>⚠</span> Please enter at least one username.</div>`; return; }

    const usernames = usersRaw.split(/[\/,\s]+/).map(u => u.trim().toLowerCase()).filter(Boolean);
    const { results } = CheckInService.postMultiArrival({ usernames, arrivalTime: time });

    const rows = results.map(r => `<tr>
      <td><strong>${r.username}</strong></td>
      <td style="font-family:var(--font-mono)">${time}</td>
      <td>${
        r.status === 'not-found' ? '<span class="badge badge--danger">Not Found</span>' :
        r.status === 'locked'    ? `<span class="badge badge--warning" title="${r.reason||''}">Locked</span>` :
        '<span class="badge badge--success">Posted</span>'
      }</td>
    </tr>`).join('');

    out.innerHTML = `
      <div class="table-container">
        <table class="table table--compact">
          <thead><tr><th>Username</th><th>Arrival</th><th>Status</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>`;

    document.getElementById('multi-users').value = '';
    document.getElementById('multi-time').value = '';

    const act = document.getElementById('co-today-activity');
    if (act) act.innerHTML = _renderTodayActivity();

    Toast.success(`Arrival ${time} posted for ${results.filter(r => r.status !== 'not-found' && r.status !== 'locked').length} user(s).`);
  };

  return Object.freeze({ render, useNow, preview, parsePaste, postMulti });
})();
