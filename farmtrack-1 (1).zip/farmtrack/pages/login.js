/**
 * pages/login.js — Login Page Controller
 *
 * Handles rendering the login page and form submission.
 * Pure page controller: reads form → calls AuthService → calls Router.
 */

const LoginPage = (() => {
  'use strict';

  const TEMPLATE = `
    <div class="auth-page">
      <!-- Left: Hero Panel -->
      <div class="auth-hero">
        <div class="auth-hero__top">
          <div class="auth-hero__logo">
            <div class="auth-hero__logo-icon">🌿</div>
            <span class="auth-hero__logo-name">FarmTrack</span>
          </div>
        </div>
        <div class="auth-hero__middle">
          <h1 class="auth-hero__tagline">Track Every Hour.<br><span>Every Farm.</span></h1>
          <p class="auth-hero__sub">
            A complete farm work management system. Check in, log arrivals, and generate detailed reports — all in one place.
          </p>
        </div>
        <div class="auth-hero__features">
          <div class="auth-hero__feature">
            <div class="auth-hero__feature-icon">✅</div>
            <span>Daily check-in with farm autocomplete</span>
          </div>
          <div class="auth-hero__feature">
            <div class="auth-hero__feature-icon">📊</div>
            <span>Weekly, mid-month & end-month reports</span>
          </div>
          <div class="auth-hero__feature">
            <div class="auth-hero__feature-icon">⬇️</div>
            <span>Download your personal PDF reports</span>
          </div>
          <div class="auth-hero__feature">
            <div class="auth-hero__feature-icon">👥</div>
            <span>Admin dashboard with charts & analytics</span>
          </div>
        </div>
      </div>

      <!-- Right: Login Form -->
      <div class="auth-form-panel">
        <div class="auth-form-wrap">
          <div class="auth-form-wrap__header">
            <h2 class="auth-form-wrap__title">Welcome back</h2>
            <p class="auth-form-wrap__subtitle">
              Don't have an account? <a href="#" onclick="Router.navigate('register')">Register here</a>
            </p>
          </div>

          <form class="auth-form" onsubmit="LoginPage.submit(event)">
            <div class="form-field">
              <label class="form-label form-label--required" for="login-username">Username</label>
              <input
                class="form-input"
                type="text"
                id="login-username"
                placeholder="Enter your username"
                autocomplete="username"
                autofocus
                required
              />
            </div>

            <div class="form-field">
              <label class="form-label form-label--required" for="login-pin-display">Password (4 digits)</label>
              <div class="pin-input-group">
                <input class="pin-digit" type="password" maxlength="1" inputmode="numeric" pattern="[0-9]" id="pin-0" data-idx="0" />
                <input class="pin-digit" type="password" maxlength="1" inputmode="numeric" pattern="[0-9]" id="pin-1" data-idx="1" />
                <input class="pin-digit" type="password" maxlength="1" inputmode="numeric" pattern="[0-9]" id="pin-2" data-idx="2" />
                <input class="pin-digit" type="password" maxlength="1" inputmode="numeric" pattern="[0-9]" id="pin-3" data-idx="3" />
              </div>
              <input type="hidden" id="login-pin" />
            </div>

            <div id="login-alert" class="hidden"></div>

            <button type="submit" class="btn btn--primary btn--block btn--lg" id="login-btn">
              Sign In
            </button>
          </form>

          <div class="auth-footer">
            <small style="color:var(--color-text-muted)">Default admin: <strong>root</strong> / <strong>1234</strong></small>
          </div>
        </div>
      </div>
    </div>
  `;

  const _setupPinInputs = () => {
    const inputs = document.querySelectorAll('.pin-digit');
    const hidden = document.getElementById('login-pin');

    const sync = () => {
      hidden.value = [...inputs].map(i => i.value).join('');
    };

    inputs.forEach((inp, i) => {
      inp.addEventListener('input', e => {
        const val = e.target.value.replace(/\D/g, '');
        inp.value = val.slice(-1); // only last digit
        inp.classList.toggle('filled', !!inp.value);
        sync();
        if (inp.value && i < inputs.length - 1) inputs[i + 1].focus();
      });
      inp.addEventListener('keydown', e => {
        if (e.key === 'Backspace' && !inp.value && i > 0) {
          inputs[i - 1].focus();
          inputs[i - 1].value = '';
          inputs[i - 1].classList.remove('filled');
          sync();
        }
        if (e.key === 'Enter') LoginPage.submit(e);
      });
      inp.addEventListener('paste', e => {
        e.preventDefault();
        const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 4);
        [...pasted].forEach((ch, j) => {
          if (inputs[j]) {
            inputs[j].value = ch;
            inputs[j].classList.add('filled');
          }
        });
        sync();
        if (inputs[pasted.length]) inputs[pasted.length].focus();
        else inputs[3]?.focus();
      });
    });
  };

  const render = el => {
    el.innerHTML = TEMPLATE;
    _setupPinInputs();
  };

  const submit = e => {
    e?.preventDefault();
    const username = document.getElementById('login-username')?.value.trim() || '';
    const pin      = document.getElementById('login-pin')?.value || '';
    const alertEl  = document.getElementById('login-alert');

    alertEl.classList.add('hidden');

    if (!username) {
      alertEl.innerHTML = '<div class="alert alert--danger"><span class="alert__icon">✕</span><span>Please enter your username.</span></div>';
      alertEl.classList.remove('hidden');
      return;
    }
    if (pin.length !== 4) {
      alertEl.innerHTML = '<div class="alert alert--danger"><span class="alert__icon">✕</span><span>Please enter all 4 PIN digits.</span></div>';
      alertEl.classList.remove('hidden');
      return;
    }

    const btn = document.getElementById('login-btn');
    btn.disabled = true;
    btn.textContent = 'Signing in…';

    setTimeout(() => {
      const result = AuthService.login(username, pin);
      if (!result.ok) {
        alertEl.innerHTML = `<div class="alert alert--danger"><span class="alert__icon">✕</span><span>${result.error}</span></div>`;
        alertEl.classList.remove('hidden');
        btn.disabled = false;
        btn.textContent = 'Sign In';
        // Clear pin
        document.querySelectorAll('.pin-digit').forEach(p => { p.value = ''; p.classList.remove('filled'); });
        document.getElementById('login-pin').value = '';
        document.getElementById('login-username').focus();
        return;
      }
      // Route to appropriate dashboard
      Router.navigate(result.user.isAdmin ? 'admin-dashboard' : 'dashboard');
    }, 180);
  };

  return Object.freeze({ render, submit });
})();
