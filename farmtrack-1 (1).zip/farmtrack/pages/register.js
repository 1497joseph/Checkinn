/**
 * pages/register.js — Registration Page Controller
 */

const RegisterPage = (() => {
  'use strict';

  const TEMPLATE = `
    <div class="auth-page">
      <!-- Left: Hero Panel -->
      <div class="auth-hero">
        <div class="auth-hero__top">
          <div class="auth-hero__logo">
            <div class="auth-hero__logo-icon">🌿</div>
            <span class="auth-hero__logo-name">FarmTrack</span>
          </div>
        </div>
        <div class="auth-hero__middle">
          <h1 class="auth-hero__tagline">Join the<br><span>Team Today.</span></h1>
          <p class="auth-hero__sub">
            Create your account to start tracking your farm work hours, generating reports, and staying organized.
          </p>
        </div>
        <div class="auth-hero__features">
          <div class="auth-hero__feature">
            <div class="auth-hero__feature-icon">🔐</div>
            <span>Secure 4-digit PIN authentication</span>
          </div>
          <div class="auth-hero__feature">
            <div class="auth-hero__feature-icon">📍</div>
            <span>Your session stays logged in</span>
          </div>
          <div class="auth-hero__feature">
            <div class="auth-hero__feature-icon">📄</div>
            <span>Personal PDF reports anytime</span>
          </div>
        </div>
      </div>

      <!-- Right: Register Form -->
      <div class="auth-form-panel">
        <div class="auth-form-wrap">
          <div class="auth-form-wrap__header">
            <h2 class="auth-form-wrap__title">Create account</h2>
            <p class="auth-form-wrap__subtitle">
              Already have an account? <a href="#" onclick="Router.navigate('login')">Sign in</a>
            </p>
          </div>

          <form class="auth-form" onsubmit="RegisterPage.submit(event)">
            <div class="form-row">
              <div class="form-field">
                <label class="form-label form-label--required" for="reg-fname">First Name</label>
                <input class="form-input" type="text" id="reg-fname" placeholder="First name" required autofocus />
              </div>
              <div class="form-field">
                <label class="form-label" for="reg-mname">Middle Name</label>
                <input class="form-input" type="text" id="reg-mname" placeholder="Middle name (optional)" />
              </div>
            </div>

            <div class="form-field">
              <label class="form-label form-label--required" for="reg-lname">Last Name</label>
              <input class="form-input" type="text" id="reg-lname" placeholder="Last name" required />
            </div>

            <div class="form-row">
              <div class="form-field">
                <label class="form-label form-label--required" for="reg-worknum">Work Number</label>
                <input class="form-input" type="text" id="reg-worknum" placeholder="e.g. WK001" required />
                <span class="form-hint">Unique identifier assigned by admin</span>
              </div>
              <div class="form-field">
                <label class="form-label form-label--required" for="reg-username">Username</label>
                <input class="form-input" type="text" id="reg-username" placeholder="e.g. dan / felix" required autocomplete="off" />
                <span class="form-hint">Lowercase, 2–20 chars</span>
              </div>
            </div>

            <div class="form-field">
              <label class="form-label form-label--required">Password (4 digits)</label>
              <div class="pin-input-group">
                <input class="pin-digit" type="password" maxlength="1" inputmode="numeric" pattern="[0-9]" id="rpinx-0" data-idx="0" />
                <input class="pin-digit" type="password" maxlength="1" inputmode="numeric" pattern="[0-9]" id="rpinx-1" data-idx="1" />
                <input class="pin-digit" type="password" maxlength="1" inputmode="numeric" pattern="[0-9]" id="rpinx-2" data-idx="2" />
                <input class="pin-digit" type="password" maxlength="1" inputmode="numeric" pattern="[0-9]" id="rpinx-3" data-idx="3" />
              </div>
              <input type="hidden" id="reg-pin" />
              <span class="form-hint">Numbers only, exactly 4 digits</span>
            </div>

            <div id="reg-alert" class="hidden"></div>

            <button type="submit" class="btn btn--primary btn--block btn--lg" id="reg-btn">
              Create Account
            </button>
          </form>
        </div>
      </div>
    </div>
  `;

  const _setupPinInputs = () => {
    const inputs = document.querySelectorAll('#page-register .pin-digit');
    const hidden = document.getElementById('reg-pin');
    const sync = () => { hidden.value = [...inputs].map(i => i.value).join(''); };

    inputs.forEach((inp, i) => {
      inp.addEventListener('input', e => {
        inp.value = e.target.value.replace(/\D/g, '').slice(-1);
        inp.classList.toggle('filled', !!inp.value);
        sync();
        if (inp.value && i < inputs.length - 1) inputs[i + 1].focus();
      });
      inp.addEventListener('keydown', e => {
        if (e.key === 'Backspace' && !inp.value && i > 0) {
          inputs[i - 1].focus(); inputs[i - 1].value = ''; inputs[i - 1].classList.remove('filled'); sync();
        }
      });
      inp.addEventListener('paste', e => {
        e.preventDefault();
        const p = e.clipboardData.getData('text').replace(/\D/g,'').slice(0,4);
        [...p].forEach((ch, j) => { if (inputs[j]) { inputs[j].value = ch; inputs[j].classList.add('filled'); } });
        sync();
        if (inputs[p.length]) inputs[p.length].focus();
      });
    });
  };

  const render = el => {
    el.innerHTML = TEMPLATE;
    _setupPinInputs();
  };

  const submit = e => {
    e?.preventDefault();
    const alertEl = document.getElementById('reg-alert');
    alertEl.classList.add('hidden');

    const data = {
      firstName:  document.getElementById('reg-fname')?.value.trim() || '',
      middleName: document.getElementById('reg-mname')?.value.trim() || '',
      lastName:   document.getElementById('reg-lname')?.value.trim() || '',
      workNumber: document.getElementById('reg-worknum')?.value.trim() || '',
      username:   document.getElementById('reg-username')?.value.trim() || '',
      pin:        document.getElementById('reg-pin')?.value || '',
    };

    if (data.pin.length !== 4) {
      alertEl.innerHTML = '<div class="alert alert--danger"><span class="alert__icon">✕</span><span>Please enter all 4 PIN digits.</span></div>';
      alertEl.classList.remove('hidden');
      return;
    }

    const btn = document.getElementById('reg-btn');
    btn.disabled = true;
    btn.textContent = 'Creating account…';

    setTimeout(() => {
      const result = AuthService.register(data);
      if (!result.ok) {
        alertEl.innerHTML = `<div class="alert alert--danger"><span class="alert__icon">✕</span><span>${result.error}</span></div>`;
        alertEl.classList.remove('hidden');
        btn.disabled = false;
        btn.textContent = 'Create Account';
        return;
      }
      Toast.success(`Welcome, ${result.user.firstName}! Account created.`);
      Router.navigate(result.user.isAdmin ? 'admin-dashboard' : 'dashboard');
    }, 200);
  };

  return Object.freeze({ render, submit });
})();
