/**
 * pages/admin-users.js — Admin Users Management Page
 */
const AdminUsersPage = (() => {
  'use strict';

  const render = el => {
    const users  = Store.getUsers();
    const today  = TimeUtils.today();
    const { from, to } = TimeUtils.currentWeek();
    el.innerHTML = `
      <div class="section-header">
        <div class="section-header__left">
          <div class="section-header__title">All Users</div>
          <div class="section-header__sub">${users.length} registered workers</div>
        </div>
      </div>
      <div class="card">
        <div class="card__header">
          <div class="card__title">
            <div class="icon" style="background:var(--color-primary-bg)">👤</div>Workers Registry
          </div>
          <input class="form-input" type="text" id="usr-search"
            placeholder="Search name or username…"
            style="max-width:260px"
            oninput="AdminUsersPage.filter()" />
        </div>
        <div class="table-container" id="usr-table">
          ${_buildTable(users, today, from, to)}
        </div>
      </div>`;
  };

  const _buildTable = (users, today, from, to) => {
    if (users.length === 0) return '<div class="empty-state"><div class="empty-state__icon">👤</div><div class="empty-state__title">No users yet</div></div>';
    const rows = users.map(u => {
      const ci         = Store.getCheckin(u.username, today);
      const rpt        = ReportService.buildUserReport(u.username, from, to);
      const initials   = ((u.firstName[0]||'')+(u.lastName[0]||'')).toUpperCase();
      return `<tr>
        <td>
          <div style="display:flex;align-items:center;gap:12px">
            <div class="avatar avatar--sm">${initials}</div>
            <div>
              <div style="font-weight:700">${Store.getFullName(u)}</div>
              <div style="font-size:var(--text-xs);color:var(--color-text-muted)">@${u.username}</div>
            </div>
          </div>
        </td>
        <td><code style="font-size:11px">${u.workNumber}</code></td>
        <td>${u.isAdmin ? '<span class="badge badge--primary">Admin</span>' : '<span class="badge badge--neutral">Worker</span>'}</td>
        <td>${ci ? '<span class="badge badge--success">✓ In</span>' : '<span class="badge badge--danger">Out</span>'}</td>
        <td style="max-width:180px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis">${ci?.farms?.join(', ')||'—'}</td>
        <td style="font-family:var(--font-mono);font-size:var(--text-xs)">${ci?.arrivalTime||'—'}</td>
        <td><span class="badge badge--primary">${rpt?.totals.days??0}d</span></td>
        <td>${(rpt?.totals.hours??0).toFixed(1)}h</td>
        <td>
          <button class="btn btn--ghost btn--sm"
            onclick="AdminUsersPage.viewUser('${u.username}')">View</button>
        </td>
      </tr>`;
    }).join('');
    return `
      <table class="table">
        <thead>
          <tr>
            <th>Name</th><th>Work #</th><th>Role</th><th>Today</th>
            <th>Farm(s)</th><th>Arrival</th><th>This Week</th><th>Hours</th><th></th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>`;
  };

  const filter = () => {
    const q = (document.getElementById('usr-search')?.value||'').toLowerCase();
    document.querySelectorAll('#usr-table tbody tr').forEach(r => {
      r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  };

  const viewUser = username => {
    const user = Store.getUserByUsername(username);
    if (!user) return;
    const { from, to } = TimeUtils.currentWeek();
    const report   = ReportService.buildUserReport(username, from, to);
    const initials = ((user.firstName[0]||'')+(user.lastName[0]||'')).toUpperCase();
    Modal.open({
      title: Store.getFullName(user),
      size: 'lg',
      content: `
        <div style="display:flex;align-items:center;gap:16px;margin-bottom:24px">
          <div class="avatar avatar--xl">${initials}</div>
          <div>
            <div style="font-size:var(--text-xl);font-weight:800">${Store.getFullName(user)}</div>
            <div style="color:var(--color-text-muted)">@${user.username} · ${user.workNumber}</div>
            <div style="margin-top:6px">
              ${user.isAdmin ? '<span class="badge badge--primary">Admin</span>' : '<span class="badge badge--neutral">Worker</span>'}
            </div>
          </div>
        </div>
        <div style="font-weight:800;margin-bottom:12px">This Week (${TimeUtils.formatDate(from,'short')} – ${TimeUtils.formatDate(to,'short')})</div>
        ${ReportRenderer.renderUserReportHTML(report, 'Weekly')}
      `,
    });
  };

  return Object.freeze({ render, filter, viewUser });
})();


/**
 * pages/admin-checkin.js — Admin Check-In Manager
 */
const AdminCheckinPage = (() => {
  'use strict';

  const render = el => {
    const users    = Store.getUsers();
    const userOpts = users.map(u =>
      `<option value="${u.username}">${Store.getFullName(u)} (@${u.username})</option>`
    ).join('');

    el.innerHTML = `
      <div class="section-header">
        <div class="section-header__left">
          <div class="section-header__title">Check-In Manager</div>
          <div class="section-header__sub">Manual check-in, arrival editing, paste parsing, revocation</div>
        </div>
      </div>

      <div class="grid-2">
        <!-- Manual check-in card -->
        <div class="card">
          <div class="card__header">
            <div class="card__title">
              <div class="icon" style="background:var(--clr-green-50)">📝</div>
              Manual Check-In
            </div>
          </div>
          <div class="card__body">
            <div class="form-group">
              <div class="form-field">
                <label class="form-label form-label--required">User</label>
                <select class="form-select" id="aci-user">${userOpts}</select>
              </div>
              <div class="form-field">
                <label class="form-label form-label--required">Date</label>
                <input class="form-input" type="date" id="aci-date" value="${TimeUtils.today()}" />
              </div>
              <div class="form-field">
                <label class="form-label">Farm(s) — comma separated</label>
                <input class="form-input" type="text" id="aci-farms" placeholder="kiamiciri, kianjiru" />
              </div>
              <div class="form-field">
                <label class="form-label">Arrival Time</label>
                <div class="time-group">
                  <button type="button" class="btn btn--ghost btn--sm"
                    onclick="document.getElementById('aci-time').value=TimeUtils.nowTime()">
                    Now
                  </button>
                  <input class="form-input" type="time" id="aci-time" style="flex:1" />
                </div>
              </div>
              <button class="btn btn--primary btn--block" onclick="AdminCheckinPage.manualCheckin()">
                Submit Check-In
              </button>
              <div id="aci-msg" class="mt-2"></div>
            </div>
          </div>
        </div>

        <!-- Edit + Revoke column -->
        <div style="display:flex;flex-direction:column;gap:var(--sp-6)">
          <div class="card">
            <div class="card__header">
              <div class="card__title">
                <div class="icon" style="background:var(--clr-amber-50)">✏️</div>
                Edit Arrival Time
              </div>
            </div>
            <div class="card__body">
              <div class="form-group">
                <div class="form-field">
                  <label class="form-label form-label--required">User</label>
                  <select class="form-select" id="aed-user">${userOpts}</select>
                </div>
                <div class="form-field">
                  <label class="form-label form-label--required">Date</label>
                  <input class="form-input" type="date" id="aed-date" value="${TimeUtils.today()}" />
                </div>
                <div class="form-field">
                  <label class="form-label form-label--required">New Arrival Time</label>
                  <div class="time-group">
                    <button type="button" class="btn btn--ghost btn--sm"
                      onclick="document.getElementById('aed-time').value=TimeUtils.nowTime()">
                      Now
                    </button>
                    <input class="form-input" type="time" id="aed-time" style="flex:1" />
                  </div>
                </div>
                <button class="btn btn--warning btn--block" onclick="AdminCheckinPage.editArrival()">
                  Update Arrival
                </button>
                <div id="aed-msg" class="mt-2"></div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card__header">
              <div class="card__title">
                <div class="icon" style="background:var(--clr-red-50)">🗑️</div>
                Revoke Check-In
              </div>
            </div>
            <div class="card__body">
              <div class="form-group">
                <div class="form-field">
                  <label class="form-label form-label--required">User</label>
                  <select class="form-select" id="arv-user">${userOpts}</select>
                </div>
                <div class="form-field">
                  <label class="form-label form-label--required">Date</label>
                  <input class="form-input" type="date" id="arv-date" value="${TimeUtils.today()}" />
                </div>
                <button class="btn btn--danger btn--block" onclick="AdminCheckinPage.revoke()">
                  Revoke Check-In
                </button>
                <div id="arv-msg" class="mt-2"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Paste text section -->
      <div class="card mt-6">
        <div class="card__header">
          <div class="card__title">
            <div class="icon" style="background:var(--color-primary-bg)">📋</div>
            Paste Collection Text — Bulk Check-In
          </div>
        </div>
        <div class="card__body">
          <div class="alert alert--info mb-4">
            <span class="alert__icon">ℹ</span>
            <div class="alert__body">
              <div class="alert__title">Supported Format</div>
              First line contains the day name. Each subsequent line: Farmer Name Farm Qty-worker1/worker2
              <br><code style="font-size:11px;display:block;margin-top:6px;background:rgba(0,0,0,0.06);padding:8px;border-radius:6px;white-space:pre">Wednesday collection
Benard Gacoki kiamiciri 1T-dan
Edith Wawira kiamiciri 400kgs-bernard
Joseph Rwika 2.5T-anthony/felix
BC
George Kamiti kiamunyeki 150kgs-joseph</code>
            </div>
          </div>
          <div class="form-field">
            <label class="form-label">Collection Text</label>
            <textarea class="form-textarea" id="adm-paste" rows="12"
              placeholder="Paste collection message here…"></textarea>
          </div>
          <div style="display:flex;gap:12px;margin-top:16px">
            <button class="btn btn--ghost" onclick="AdminCheckinPage.previewPaste()">👁 Preview</button>
            <button class="btn btn--primary" onclick="AdminCheckinPage.parsePaste()">✅ Parse & Check-In All</button>
          </div>
          <div id="adm-paste-result" class="mt-4"></div>
        </div>
      </div>`;
  };

  const _msg = (id, html) => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = html;
  };

  const manualCheckin = () => {
    const username = document.getElementById('aci-user')?.value;
    const date     = document.getElementById('aci-date')?.value;
    const farmsRaw = document.getElementById('aci-farms')?.value||'';
    const time     = document.getElementById('aci-time')?.value||'';
    const farms    = farmsRaw.split(',').map(f=>f.trim()).filter(Boolean);
    const result   = CheckInService.adminManualCheckIn({ username, date, farms, arrivalTime: time||undefined });
    _msg('aci-msg', result.ok
      ? `<div class="alert alert--success"><span class="alert__icon">✓</span><span>Check-in saved for <strong>${username}</strong> on ${date}.</span></div>`
      : `<div class="alert alert--danger"><span class="alert__icon">✕</span><span>${result.error}</span></div>`);
    if (result.ok) Toast.success('Check-in saved.');
  };

  const editArrival = () => {
    const username = document.getElementById('aed-user')?.value;
    const date     = document.getElementById('aed-date')?.value;
    const time     = document.getElementById('aed-time')?.value;
    if (!time) { _msg('aed-msg','<div class="alert alert--danger"><span>⚠</span><span>Select a time.</span></div>'); return; }
    const result = CheckInService.adminEditArrival({ username, date, arrivalTime: time });
    _msg('aed-msg', result.ok
      ? `<div class="alert alert--success"><span class="alert__icon">✓</span><span>Arrival updated to <strong>${time}</strong> for ${username}.</span></div>`
      : `<div class="alert alert--danger"><span class="alert__icon">✕</span><span>${result.error}</span></div>`);
    if (result.ok) Toast.success('Arrival updated.');
  };

  const revoke = () => {
    const username = document.getElementById('arv-user')?.value;
    const date     = document.getElementById('arv-date')?.value;
    if (!confirm(`Revoke check-in for ${username} on ${date}? This cannot be undone.`)) return;
    const result = CheckInService.adminRevokeCheckIn({ username, date });
    _msg('arv-msg', result.ok
      ? `<div class="alert alert--success"><span class="alert__icon">✓</span><span>Check-in revoked for ${username} on ${date}.</span></div>`
      : `<div class="alert alert--danger"><span class="alert__icon">✕</span><span>${result.error}</span></div>`);
    if (result.ok) Toast.success('Check-in revoked.');
  };

  const previewPaste = () => {
    const text   = document.getElementById('adm-paste')?.value||'';
    const parsed = CheckInService.parsePasteText(text);
    const out    = document.getElementById('adm-paste-result');
    if (!parsed.ok) {
      out.innerHTML = `<div class="alert alert--danger"><span class="alert__icon">✕</span><span>${parsed.error}</span></div>`;
      return;
    }
    const list = parsed.entries.map(e =>
      `<li><strong>${e.workers.join(' / ')}</strong> → 🌾 ${e.farm} (farmer: ${e.farmer})</li>`
    ).join('');
    out.innerHTML = `
      <div class="alert alert--info">
        <span class="alert__icon">ℹ</span>
        <div class="alert__body">
          <div class="alert__title">Preview: ${parsed.dayName} — ${parsed.date}</div>
          <ul style="margin:8px 0 0 16px;line-height:1.8">${list}</ul>
        </div>
      </div>`;
  };

  const parsePaste = () => {
    const text   = document.getElementById('adm-paste')?.value||'';
    const out    = document.getElementById('adm-paste-result');
    const parsed = CheckInService.parsePasteText(text);
    if (!parsed.ok) {
      out.innerHTML = `<div class="alert alert--danger"><span class="alert__icon">✕</span><span>${parsed.error}</span></div>`;
      return;
    }
    const { results } = CheckInService.applyParsedCheckIns(parsed);
    const rows = results.map(r => `<tr>
      <td><strong>${r.worker}</strong></td>
      <td>${r.farm}</td>
      <td>${r.farmer||'—'}</td>
      <td>${r.status==='not-found'
        ? '<span class="badge badge--danger">Not Found</span>'
        : r.status==='updated'
        ? '<span class="badge badge--warning">Updated</span>'
        : '<span class="badge badge--success">Checked In</span>'}</td>
    </tr>`).join('');
    out.innerHTML = `
      <div class="alert alert--success mb-4">
        <span class="alert__icon">✓</span>
        <span>Processed ${results.length} entries for <strong>${parsed.dayName}</strong> (${parsed.date})</span>
      </div>
      <div class="table-container">
        <table class="table table--compact">
          <thead><tr><th>Worker</th><th>Farm</th><th>Farmer</th><th>Status</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>`;
    Toast.success(`${results.filter(r=>r.status!=='not-found').length} workers checked in.`);
  };

  return Object.freeze({ render, manualCheckin, editArrival, revoke, previewPaste, parsePaste });
})();


/**
 * pages/admin-reports.js — Admin All-Users Reports Page
 */
const AdminReportsPage = (() => {
  'use strict';

  let _activeTab = 'weekly';

  const render = el => {
    el.innerHTML = `
      <div class="section-header">
        <div class="section-header__left">
          <div class="section-header__title">All Reports</div>
          <div class="section-header__sub">Generate, view and download reports for all workers</div>
        </div>
      </div>

      <div class="tab-pill-group mb-6">
        <button class="tab-pill ${_activeTab==='weekly'?'tab-pill--active':''}"
          onclick="AdminReportsPage.switchTab('weekly')">📅 Weekly</button>
        <button class="tab-pill ${_activeTab==='midmonth'?'tab-pill--active':''}"
          onclick="AdminReportsPage.switchTab('midmonth')">📆 Mid-Month</button>
        <button class="tab-pill ${_activeTab==='endmonth'?'tab-pill--active':''}"
          onclick="AdminReportsPage.switchTab('endmonth')">🗓 End of Month</button>
        <button class="tab-pill ${_activeTab==='custom'?'tab-pill--active':''}"
          onclick="AdminReportsPage.switchTab('custom')">🗂 Custom Range</button>
      </div>

      <!-- Weekly -->
      <div id="artab-weekly" style="display:${_activeTab==='weekly'?'block':'none'}">
        <div class="card">
          <div class="card__header">
            <div class="card__title">
              <div class="icon" style="background:var(--color-primary-bg)">📅</div>Weekly Report — All Users
            </div>
          </div>
          <div class="card__body">
            <div class="form-row" style="align-items:flex-end">
              <div class="form-field" style="flex:1">
                <label class="form-label">Select any date within the week</label>
                <input class="form-input" type="date" id="ar-week-date" value="${TimeUtils.today()}" />
              </div>
              <button class="btn btn--primary" onclick="AdminReportsPage.generateWeekly()">Generate</button>
            </div>
          </div>
        </div>
        <div id="ar-weekly-result"></div>
      </div>

      <!-- Mid Month -->
      <div id="artab-midmonth" style="display:${_activeTab==='midmonth'?'block':'none'}">
        <div class="card">
          <div class="card__header">
            <div class="card__title">
              <div class="icon" style="background:var(--clr-green-50)">📆</div>Mid-Month Report (1–15)
            </div>
          </div>
          <div class="card__body">
            <div class="form-row" style="align-items:flex-end">
              <div class="form-field" style="flex:1">
                <label class="form-label">Select Month</label>
                <input class="form-input" type="month" id="ar-mid-month" value="${TimeUtils.toMonthStr()}" />
              </div>
              <button class="btn btn--primary" onclick="AdminReportsPage.generateMidMonth()">Generate</button>
            </div>
          </div>
        </div>
        <div id="ar-mid-result"></div>
      </div>

      <!-- End Month -->
      <div id="artab-endmonth" style="display:${_activeTab==='endmonth'?'block':'none'}">
        <div class="card">
          <div class="card__header">
            <div class="card__title">
              <div class="icon" style="background:var(--clr-amber-50)">🗓</div>End-of-Month Report
            </div>
          </div>
          <div class="card__body">
            <div class="form-row" style="align-items:flex-end">
              <div class="form-field" style="flex:1">
                <label class="form-label">Select Month</label>
                <input class="form-input" type="month" id="ar-end-month" value="${TimeUtils.toMonthStr()}" />
              </div>
              <button class="btn btn--primary" onclick="AdminReportsPage.generateEndMonth()">Generate</button>
            </div>
          </div>
        </div>
        <div id="ar-end-result"></div>
      </div>

      <!-- Custom -->
      <div id="artab-custom" style="display:${_activeTab==='custom'?'block':'none'}">
        <div class="card">
          <div class="card__header">
            <div class="card__title">
              <div class="icon" style="background:var(--clr-primary-50)">🗂</div>Custom Date Range
            </div>
          </div>
          <div class="card__body">
            <div class="form-row" style="align-items:flex-end">
              <div class="form-field" style="flex:1">
                <label class="form-label">From</label>
                <input class="form-input" type="date" id="ar-custom-from" value="${TimeUtils.weekRange().from}" />
              </div>
              <div class="form-field" style="flex:1">
                <label class="form-label">To</label>
                <input class="form-input" type="date" id="ar-custom-to" value="${TimeUtils.today()}" />
              </div>
              <button class="btn btn--primary" onclick="AdminReportsPage.generateCustom()">Generate</button>
            </div>
          </div>
        </div>
        <div id="ar-custom-result"></div>
      </div>`;
  };

  const switchTab = tab => {
    _activeTab = tab;
    ['weekly','midmonth','endmonth','custom'].forEach(t => {
      const panel = document.getElementById(`artab-${t}`);
      const pill  = document.querySelector(`.tab-pill[onclick="AdminReportsPage.switchTab('${t}')"]`);
      if (panel) panel.style.display = t===tab ? 'block' : 'none';
      if (pill)  pill.classList.toggle('tab-pill--active', t===tab);
    });
  };

  const generateWeekly = () => {
    const d = document.getElementById('ar-week-date')?.value;
    if (!d) return;
    const { from, to } = TimeUtils.weekRange(d);
    const reports = ReportService.allUsersWeeklyReport(d);
    document.getElementById('ar-weekly-result').innerHTML =
      ReportRenderer.renderAllUsersReportHTML(reports, 'Weekly Report', from, to);
  };

  const generateMidMonth = () => {
    const m = document.getElementById('ar-mid-month')?.value;
    if (!m) return;
    const from = `${m}-01`, to = `${m}-15`;
    const reports = ReportService.allUsersMidMonthReport(m);
    document.getElementById('ar-mid-result').innerHTML =
      ReportRenderer.renderAllUsersReportHTML(reports, `Mid-Month Report ${m}`, from, to);
  };

  const generateEndMonth = () => {
    const m = document.getElementById('ar-end-month')?.value;
    if (!m) return;
    const [y,mo] = m.split('-').map(Number);
    const last = TimeUtils.lastDayOfMonth(y, mo);
    const from = `${m}-01`, to = `${m}-${String(last).padStart(2,'0')}`;
    const reports = ReportService.allUsersEndMonthReport(m);
    document.getElementById('ar-end-result').innerHTML =
      ReportRenderer.renderAllUsersReportHTML(reports, `End-of-Month Report ${m}`, from, to);
  };

  const generateCustom = () => {
    const from = document.getElementById('ar-custom-from')?.value;
    const to   = document.getElementById('ar-custom-to')?.value;
    if (!from||!to) return;
    if (from>to) { Toast.error('From date must be before To date.'); return; }
    const reports = ReportService.allUsersCustomReport(from, to);
    document.getElementById('ar-custom-result').innerHTML =
      ReportRenderer.renderAllUsersReportHTML(reports, `Custom Report`, from, to);
  };

  return Object.freeze({ render, switchTab, generateWeekly, generateMidMonth, generateEndMonth, generateCustom });
})();
