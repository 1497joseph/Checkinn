/**
 * pages/admin-dashboard.js — Admin Dashboard Page Controller
 */

const AdminDashboardPage = (() => {
  'use strict';

  let _clockStop = null;

  const render = el => {
    const today  = TimeUtils.today();
    const users  = Store.getUsers();
    const { from, to } = TimeUtils.currentWeek();

    // Today's check-in summary
    const checkedIn = users.filter(u => Store.getCheckin(u.username, today));
    const notIn     = users.filter(u => !Store.getCheckin(u.username, today));

    // This week totals
    const weekCheckins = Store.getCheckinsByRange(from, to);
    const totalHoursThisWeek = weekCheckins.reduce((s, c) => s + TimeUtils.hoursWorked(c.arrivalTime), 0);
    const totalOTThisWeek    = weekCheckins.reduce((s, c) => s + TimeUtils.overtimeMinutes(c.arrivalTime), 0) / 60;

    // User status cards
    const inCards  = checkedIn.map(u => _userStatusCard(u, today, true)).join('');
    const outCards = notIn.map(u => _userStatusCard(u, today, false)).join('');

    el.innerHTML = `
      <!-- Banner -->
      <div class="welcome-banner" style="background:linear-gradient(135deg,#0b1a2e 0%,#0d3e8f 50%,#1259c3 100%)">
        <div class="welcome-banner__left">
          <div class="welcome-banner__greeting">Admin Overview</div>
          <div class="welcome-banner__name">⭐ ${Store.getFullName(AuthService.getCurrentUser())}</div>
          <div class="welcome-banner__meta">${users.length} total workers · Week: ${TimeUtils.formatDate(from,'short')} – ${TimeUtils.formatDate(to,'short')}</div>
        </div>
        <div class="welcome-banner__right">
          <div class="welcome-banner__date" id="adash-date"></div>
          <div class="welcome-banner__time" id="adash-clock">--:--:--</div>
        </div>
      </div>

      <!-- Stats -->
      <div class="grid-4 mb-6">
        <div class="stat-card stat-card--blue">
          <div class="stat-card__icon">👥</div>
          <div class="stat-card__value">${users.length}</div>
          <div class="stat-card__label">Total Workers</div>
        </div>
        <div class="stat-card stat-card--green">
          <div class="stat-card__icon">✅</div>
          <div class="stat-card__value">${checkedIn.length}</div>
          <div class="stat-card__label">In Today</div>
        </div>
        <div class="stat-card">
          <div class="stat-card__icon">⏱️</div>
          <div class="stat-card__value">${totalHoursThisWeek.toFixed(0)}h</div>
          <div class="stat-card__label">Hours This Week</div>
        </div>
        <div class="stat-card ${totalOTThisWeek > 0 ? 'stat-card--amber' : ''}">
          <div class="stat-card__icon">🕐</div>
          <div class="stat-card__value">${totalOTThisWeek.toFixed(1)}h</div>
          <div class="stat-card__label">OT This Week</div>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="card mb-6">
        <div class="card__header">
          <div class="card__title"><div class="icon" style="background:var(--clr-amber-50)">⚡</div>Quick Actions</div>
        </div>
        <div class="card__body" style="display:flex;gap:var(--sp-3);flex-wrap:wrap">
          <button class="btn btn--primary" onclick="Router.navigate('admin-checkin')">📝 Check-In Manager</button>
          <button class="btn btn--ghost" onclick="Router.navigate('admin-reports')">📁 Generate Reports</button>
          <button class="btn btn--ghost" onclick="Router.navigate('admin-charts')">📈 View Charts</button>
          <button class="btn btn--ghost" onclick="Router.navigate('admin-suggestions')">💡 Work Suggestions</button>
          <button class="btn btn--ghost" onclick="Router.navigate('checkin')">✅ My Check-In</button>
        </div>
      </div>

      <!-- Workers Status -->
      <div class="grid-2">
        <div class="card">
          <div class="card__header">
            <div class="card__title">
              <div class="icon" style="background:var(--clr-green-50)">✅</div>
              Checked In Today (${checkedIn.length})
            </div>
          </div>
          <div class="card__body">
            ${checkedIn.length > 0
              ? `<div class="user-status-grid">${inCards}</div>`
              : `<div class="empty-state"><div class="empty-state__icon">🌅</div><div class="empty-state__title">No one in yet</div></div>`
            }
          </div>
        </div>
        <div class="card">
          <div class="card__header">
            <div class="card__title">
              <div class="icon" style="background:var(--clr-red-50)">⬜</div>
              Not In Today (${notIn.length})
            </div>
          </div>
          <div class="card__body">
            ${notIn.length > 0
              ? `<div class="user-status-grid">${outCards}</div>`
              : `<div class="empty-state"><div class="empty-state__icon">🎉</div><div class="empty-state__title">Everyone is in!</div></div>`
            }
          </div>
        </div>
      </div>
    `;

    if (_clockStop) _clockStop();
    _clockStop = TimeUtils.startLiveClock((t, d) => {
      const ec = document.getElementById('adash-clock');
      const ed = document.getElementById('adash-date');
      if (ec) ec.textContent = t;
      if (ed) ed.textContent = d;
    });
  };

  const _userStatusCard = (user, today, isIn) => {
    const ci = isIn ? Store.getCheckin(user.username, today) : null;
    const initials = ((user.firstName[0]||'') + (user.lastName[0]||'')).toUpperCase();
    const otMins = ci ? TimeUtils.overtimeMinutes(ci.arrivalTime) : 0;
    return `
      <div class="user-status-card ${isIn ? 'user-status-card--in' : ''}">
        <div class="avatar avatar--sm">${initials}</div>
        <div class="user-status-card__info">
          <div class="user-status-card__name">${user.firstName} ${user.lastName}</div>
          <div class="user-status-card__detail">
            ${isIn && ci?.farms?.length ? '🌾 ' + ci.farms.join(', ').slice(0, 24) : '@' + user.username}
          </div>
        </div>
        ${isIn ? `
          <div style="text-align:right">
            <div class="user-status-card__time">${ci?.arrivalTime || '—'}</div>
            ${otMins > 0 ? `<div style="font-size:10px;color:var(--color-warning);font-weight:700">OT</div>` : ''}
          </div>
        ` : `<span class="badge badge--neutral">Out</span>`}
      </div>`;
  };

  const destroy = () => { if (_clockStop) { _clockStop(); _clockStop = null; } };

  return Object.freeze({ render, destroy });
})();
