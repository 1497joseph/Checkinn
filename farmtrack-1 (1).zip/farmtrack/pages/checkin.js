/**
 * pages/checkin.js — Check-In Page Controller
 */

const CheckInPage = (() => {
  'use strict';

  const render = el => {
    const user    = AuthService.getCurrentUser();
    const today   = TimeUtils.today();
    const todayCI = Store.getCheckin(user.username, today);
    const isLocked = CheckInService.isArrivalLocked();
    const { from, to } = TimeUtils.currentWeek();

    el.innerHTML = `
      <div class="section-header">
        <div class="section-header__left">
          <div class="section-header__title">Check In</div>
          <div class="section-header__sub">Record your farm attendance for today</div>
        </div>
      </div>

      <div class="grid-2">
        <!-- Check-in form -->
        <div class="card">
          <div class="card__header">
            <div class="card__title">
              <div class="icon" style="background:var(--clr-green-50)">🌾</div>
              Today's Check-In
            </div>
            <span class="badge ${todayCI ? 'badge--success' : 'badge--neutral'}">${todayCI ? '✓ Checked In' : 'Not In'}</span>
          </div>
          <div class="card__body">
            ${isLocked ? `
              <div class="alert alert--info mb-4">
                <span class="alert__icon">ℹ</span>
                <div class="alert__body">
                  <div class="alert__title">Arrival Locked</div>
                  Arrival time <strong>${todayCI?.arrivalTime}</strong> was posted for you by <strong>${todayCI?.lockedBy}</strong>. Only admin can change it.
                </div>
              </div>
            ` : ''}

            <form class="form-group" onsubmit="CheckInPage.submit(event)">
              <div class="form-field">
                <label class="form-label form-label--required" for="ci-farm">Farm Name</label>
                <div class="autocomplete" id="ci-autocomplete-wrap">
                  <input
                    class="form-input"
                    type="text"
                    id="ci-farm"
                    placeholder="Start typing farm name…"
                    autocomplete="off"
                    oninput="CheckInPage.farmAutocomplete(this)"
                  />
                  <div class="autocomplete__list hidden" id="ci-farm-list"></div>
                </div>
              </div>

              <div class="form-field">
                <label class="form-label">Arrival Time ${isLocked ? '<span class="badge badge--warning" style="margin-left:6px">Locked</span>' : ''}</label>
                <div class="time-group">
                  <button type="button" class="btn btn--ghost btn--sm" onclick="CheckInPage.useNow()" ${isLocked ? 'disabled' : ''}>
                    📍 Use Current Time
                  </button>
                  <span class="divider">or</span>
                  <input class="form-input" type="time" id="ci-time" ${isLocked ? 'disabled' : ''} style="flex:1" />
                </div>
                ${isLocked ? `<span class="form-hint">Arrival: ${todayCI?.arrivalTime}. Contact admin to change.</span>` : '<span class="form-hint">Optional — leave blank to record later.</span>'}
              </div>

              <div id="ci-alert" class="hidden mt-2"></div>

              <button type="submit" class="btn btn--primary btn--lg btn--block">
                ✅ Check In
              </button>
            </form>
          </div>
        </div>

        <!-- Today summary -->
        <div>
          ${todayCI ? `
            <div class="card mb-6">
              <div class="card__header">
                <div class="card__title"><div class="icon" style="background:var(--clr-green-50)">📍</div>Today's Record</div>
              </div>
              <div class="card__body">
                <div style="display:flex;flex-direction:column;gap:var(--sp-4)">
                  <div>
                    <div class="form-label">Farms Today</div>
                    <div style="margin-top:4px;display:flex;flex-wrap:wrap;gap:6px">
                      ${todayCI.farms.map(f => `<span class="badge badge--primary">🌾 ${f}</span>`).join('') || '<span style="color:var(--color-text-muted)">None recorded</span>'}
                    </div>
                  </div>
                  <div>
                    <div class="form-label">Arrival Time</div>
                    <div style="font-family:var(--font-mono);font-size:var(--text-xl);font-weight:800;margin-top:4px;color:var(--color-primary)">
                      ${todayCI.arrivalTime || '—'}
                    </div>
                  </div>
                  ${TimeUtils.overtimeMinutes(todayCI.arrivalTime) > 0 ? `
                    <div class="alert alert--warning">
                      <span class="alert__icon">⚠</span>
                      <div>Overtime: <strong>${TimeUtils.fmtMinutes(TimeUtils.overtimeMinutes(todayCI.arrivalTime))}</strong></div>
                    </div>
                  ` : ''}
                  <div>
                    <div class="form-label">Hours Worked</div>
                    <div style="font-size:var(--text-xl);font-weight:800;color:var(--color-text);margin-top:4px">
                      ${TimeUtils.hoursWorked(todayCI.arrivalTime).toFixed(2)}h
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ` : ''}

          <div class="card">
            <div class="card__header">
              <div class="card__title"><div class="icon" style="background:var(--color-primary-bg)">📋</div>This Week</div>
            </div>
            <div class="card__body" id="ci-week-list">
              ${_renderWeekList(from, to, user.username, today)}
            </div>
          </div>
        </div>
      </div>
    `;
  };

  const _renderWeekList = (from, to, username, today) => {
    const dates  = TimeUtils.datesBetween(from, to);
    const cis    = Store.getUserCheckinsByRange(username, from, to);
    const ciMap  = Object.fromEntries(cis.map(c => [c.date, c]));

    return dates.map(d => {
      const ci      = ciMap[d];
      const dayName = TimeUtils.getDayName(d);
      const isToday = d === today;
      if (!ci) return `
        <div class="timeline-item">
          <div class="timeline-dot timeline-dot--inactive"></div>
          <div class="timeline-content">
            <div class="timeline-title" style="${isToday ? 'color:var(--color-primary);font-weight:800' : ''}">${dayName.slice(0,3)} ${isToday ? '· <span style="font-size:var(--text-xs);color:var(--color-primary)">Today</span>' : ''}</div>
            <div class="timeline-sub">${TimeUtils.formatDate(d,'short')}</div>
          </div>
          <span class="badge badge--neutral" style="font-size:10px">Off</span>
        </div>`;
      const otMins = TimeUtils.overtimeMinutes(ci.arrivalTime);
      return `
        <div class="timeline-item">
          <div class="timeline-dot ${otMins > 0 ? 'timeline-dot--warning' : 'timeline-dot--active'}"></div>
          <div class="timeline-content">
            <div class="timeline-title" style="${isToday ? 'color:var(--color-primary);font-weight:800' : ''}">${dayName.slice(0,3)} ${isToday ? '· <span style="font-size:var(--text-xs);color:var(--color-primary)">Today</span>' : ''}</div>
            <div class="timeline-sub">🌾 ${ci.farms.join(', ') || '—'}</div>
          </div>
          <div style="text-align:right">
            <div class="timeline-meta">${ci.arrivalTime || '—'}</div>
            ${otMins > 0 ? `<div style="font-size:10px;color:var(--color-warning);font-weight:700">OT: ${TimeUtils.fmtMinutes(otMins)}</div>` : ''}
          </div>
        </div>`;
    }).join('');
  };

  const farmAutocomplete = input => {
    const val  = input.value.trim().toLowerCase();
    const list = document.getElementById('ci-farm-list');
    if (!list) return;
    if (!val) { list.classList.add('hidden'); return; }

    const farms = Store.getAllFarms().filter(f => f.toLowerCase().includes(val));
    if (farms.length === 0) { list.classList.add('hidden'); return; }

    list.innerHTML = farms.map(f =>
      `<div class="autocomplete__item" onclick="CheckInPage.selectFarm('${f.replace(/'/g,"\\'")}')">
        <span>🌾</span><span>${f}</span>
      </div>`
    ).join('');
    list.classList.remove('hidden');
  };

  const selectFarm = name => {
    const inp = document.getElementById('ci-farm');
    if (inp) inp.value = name;
    document.getElementById('ci-farm-list')?.classList.add('hidden');
  };

  const useNow = () => {
    const inp = document.getElementById('ci-time');
    if (inp) inp.value = TimeUtils.nowTime();
  };

  const submit = e => {
    e?.preventDefault();
    const farm     = document.getElementById('ci-farm')?.value.trim() || '';
    const time     = document.getElementById('ci-time')?.value || '';
    const alertEl  = document.getElementById('ci-alert');
    alertEl.classList.add('hidden');

    const result = CheckInService.selfCheckIn({ farm, arrivalTime: time || undefined });

    if (!result.ok) {
      alertEl.innerHTML = `<div class="alert alert--danger"><span class="alert__icon">✕</span><span>${result.error}</span></div>`;
      alertEl.classList.remove('hidden');
      return;
    }

    const msg = result.locked
      ? `Farm "${farm}" recorded. Arrival time was already set.`
      : `✅ Checked in for "${farm}"${time ? ' at ' + time : ''}.`;

    Toast.success(msg);
    document.getElementById('ci-farm').value = '';
    document.getElementById('ci-time').value = '';

    // Re-render page
    const el = document.getElementById('page-checkin');
    if (el) render(el);
  };

  // Close autocomplete on outside click
  document.addEventListener('click', e => {
    const wrap = document.getElementById('ci-autocomplete-wrap');
    if (wrap && !wrap.contains(e.target)) {
      document.getElementById('ci-farm-list')?.classList.add('hidden');
    }
  });

  return Object.freeze({ render, submit, farmAutocomplete, selectFarm, useNow });
})();
