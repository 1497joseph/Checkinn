/**
 * pages/dashboard.js — User Dashboard Page Controller
 *
 * Shows: welcome banner, today status, weekly stats, week timeline.
 */

const DashboardPage = (() => {
  'use strict';

  let _clockStop = null;

  const render = el => {
    const user  = AuthService.getCurrentUser();
    const today = TimeUtils.today();
    const { from, to } = TimeUtils.currentWeek();
    const todayCI  = Store.getCheckin(user.username, today);
    const weekReport = ReportService.buildUserReport(user.username, from, to);

    const fullName = Store.getFullName(user);
    const initials = ((user.firstName[0]||'') + (user.lastName[0]||'')).toUpperCase();

    // Today status
    const isIn       = !!todayCI;
    const otMins     = todayCI ? TimeUtils.overtimeMinutes(todayCI.arrivalTime) : 0;
    const totalDays  = weekReport?.totals.days ?? 0;
    const totalHours = weekReport?.totals.hours ?? 0;
    const totalOT    = weekReport?.totals.otHours ?? 0;

    // Week progress (48h target)
    const progressPct = Math.min(100, Math.round((totalHours / 48) * 100));

    // Week timeline HTML
    const weekDates = TimeUtils.datesBetween(from, to);
    const checkinMap = Object.fromEntries(
      (weekReport?.days || []).map(d => [d.date, d])
    );

    const timelineHTML = weekDates.map(d => {
      const ci      = checkinMap[d];
      const dayName = TimeUtils.getDayName(d);
      const shortDate = TimeUtils.formatDate(d, 'short');
      const isToday = d === today;

      if (!ci) return `
        <div class="timeline-item">
          <div class="timeline-dot timeline-dot--inactive"></div>
          <div class="timeline-content">
            <div class="timeline-title" style="${isToday ? 'color:var(--color-primary);font-weight:800' : ''}">${dayName}${isToday ? ' <span class="badge badge--primary" style="font-size:9px">TODAY</span>' : ''}</div>
            <div class="timeline-sub">${shortDate}</div>
          </div>
          <span class="badge badge--neutral">Not in</span>
        </div>`;

      const otBadge = ci.otMins > 0
        ? `<span class="badge badge--warning">OT: ${TimeUtils.fmtMinutes(ci.otMins)}</span>`
        : '<span class="badge badge--success">On time</span>';

      return `
        <div class="timeline-item">
          <div class="timeline-dot ${ci.otMins > 0 ? 'timeline-dot--warning' : 'timeline-dot--active'}"></div>
          <div class="timeline-content">
            <div class="timeline-title" style="${isToday ? 'color:var(--color-primary);font-weight:800' : ''}">${dayName}${isToday ? ' <span class="badge badge--primary" style="font-size:9px">TODAY</span>' : ''}</div>
            <div class="timeline-sub">🌾 ${ci.farms.join(', ') || '—'} · ${shortDate}</div>
          </div>
          <div style="text-align:right">
            <div class="timeline-meta">${ci.arrivalTime || '—'}</div>
            ${otBadge}
          </div>
        </div>`;
    }).join('');

    // Circumference for progress ring
    const R = 52, C = 2 * Math.PI * R;
    const dash = C - (progressPct / 100) * C;

    el.innerHTML = `
      <!-- Welcome Banner -->
      <div class="welcome-banner">
        <div class="welcome-banner__left">
          <div class="welcome-banner__greeting">Good ${_greeting()}</div>
          <div class="welcome-banner__name">${fullName} 👋</div>
          <div class="welcome-banner__meta">
            ${user.isAdmin ? '⭐ Administrator · ' : ''}Work #: ${user.workNumber}
          </div>
        </div>
        <div class="welcome-banner__right">
          <div class="welcome-banner__date" id="dash-date-display"></div>
          <div class="welcome-banner__time" id="dash-clock">--:--:--</div>
        </div>
      </div>

      <!-- Stat Cards -->
      <div class="grid-4 mb-6">
        <div class="stat-card ${isIn ? 'stat-card--green' : ''}">
          <div class="stat-card__icon">${isIn ? '✅' : '⬜'}</div>
          <div class="stat-card__value">${isIn ? 'In' : 'Out'}</div>
          <div class="stat-card__label">Today's Status</div>
        </div>
        <div class="stat-card stat-card--blue">
          <div class="stat-card__icon">📅</div>
          <div class="stat-card__value">${totalDays}</div>
          <div class="stat-card__label">Days This Week</div>
        </div>
        <div class="stat-card">
          <div class="stat-card__icon">⏱️</div>
          <div class="stat-card__value">${totalHours.toFixed(1)}h</div>
          <div class="stat-card__label">Hours This Week</div>
        </div>
        <div class="stat-card ${totalOT > 0 ? 'stat-card--amber' : ''}">
          <div class="stat-card__icon">🕐</div>
          <div class="stat-card__value">${totalOT.toFixed(1)}h</div>
          <div class="stat-card__label">Overtime</div>
        </div>
      </div>

      <!-- Main Grid -->
      <div class="grid-cols-main">
        <!-- Left: Week Timeline -->
        <div class="card">
          <div class="card__header">
            <div class="card__title">
              <div class="icon" style="background:#E8F9EE">📆</div>
              This Week's Work
            </div>
            <button class="btn btn--ghost btn--sm" onclick="Router.navigate('checkin')">+ Check In</button>
          </div>
          <div class="card__body">${timelineHTML || '<div class="empty-state"><div class="empty-state__icon">📭</div><div class="empty-state__title">No check-ins yet</div><div class="empty-state__text">Check in to start tracking your work this week.</div></div>'}</div>
        </div>

        <!-- Right Column -->
        <div style="display:flex;flex-direction:column;gap:var(--sp-6)">
          <!-- Today Card -->
          <div class="card">
            <div class="card__header">
              <div class="card__title">
                <div class="icon" style="background:${isIn ? 'var(--clr-green-50)' : 'var(--color-surface-alt)'}">🌾</div>
                Today
              </div>
            </div>
            <div class="card__body">
              ${isIn ? `
                <div class="today-status today-status--checkedin">
                  <div class="today-status__icon">✅</div>
                  <div class="today-status__label">Checked In</div>
                  <div class="today-status__farms">🌾 ${todayCI.farms.join(', ') || 'No farm recorded'}</div>
                  ${todayCI.arrivalTime ? `<div class="today-status__time">${todayCI.arrivalTime}</div>` : '<div style="color:var(--color-text-muted);font-size:var(--text-sm)">Arrival not recorded yet</div>'}
                  ${otMins > 0 ? `<span class="badge badge--warning">OT: ${TimeUtils.fmtMinutes(otMins)}</span>` : ''}
                </div>
                <button class="btn btn--ghost btn--block mt-4" onclick="Router.navigate('checkin')">Add Another Farm</button>
              ` : `
                <div class="today-status today-status--out">
                  <div class="today-status__icon">⬜</div>
                  <div class="today-status__label">Not Checked In</div>
                  <p style="font-size:var(--text-sm)">Check in to start today's work log.</p>
                </div>
                <button class="btn btn--primary btn--block mt-4" onclick="Router.navigate('checkin')">Check In Now</button>
              `}
            </div>
          </div>

          <!-- Week Progress -->
          <div class="card">
            <div class="card__header">
              <div class="card__title">
                <div class="icon" style="background:var(--color-primary-bg)">🎯</div>
                Weekly Progress
              </div>
            </div>
            <div class="card__body">
              <div class="week-progress">
                <div class="progress-ring">
                  <svg width="130" height="130" viewBox="0 0 130 130">
                    <circle class="progress-ring__bg" cx="65" cy="65" r="${R}" stroke-width="10"/>
                    <circle
                      class="progress-ring__fill"
                      cx="65" cy="65" r="${R}"
                      stroke-width="10"
                      stroke-dasharray="${C}"
                      stroke-dashoffset="${dash}"
                    />
                  </svg>
                  <div class="progress-ring__text">
                    <div class="progress-ring__value">${progressPct}%</div>
                    <div class="progress-ring__unit">of 48h</div>
                  </div>
                </div>
                <div style="text-align:center">
                  <div style="font-weight:800;font-size:var(--text-lg)">${totalHours.toFixed(1)} / 48h</div>
                  <div style="font-size:var(--text-sm);color:var(--color-text-muted)">${48 - totalHours > 0 ? (48 - totalHours).toFixed(1) + 'h remaining' : 'Target reached!'}</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Quick Links -->
          <div class="card">
            <div class="card__header">
              <div class="card__title"><div class="icon" style="background:var(--clr-amber-50)">⚡</div>Quick Actions</div>
            </div>
            <div class="card__body" style="display:flex;flex-direction:column;gap:var(--sp-3)">
              <button class="btn btn--subtle btn--block" onclick="Router.navigate('reports')">📊 My Reports</button>
              <button class="btn btn--subtle btn--block" onclick="Router.navigate('checkin-others')">👥 Check-In Others</button>
            </div>
          </div>
        </div>
      </div>
    `;

    // Start live clock
    if (_clockStop) _clockStop();
    _clockStop = TimeUtils.startLiveClock((t, d) => {
      const el1 = document.getElementById('dash-clock');
      const el2 = document.getElementById('dash-date-display');
      if (el1) el1.textContent = t;
      if (el2) el2.textContent = d;
    });
  };

  const _greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'morning';
    if (h < 17) return 'afternoon';
    return 'evening';
  };

  const destroy = () => { if (_clockStop) { _clockStop(); _clockStop = null; } };

  return Object.freeze({ render, destroy });
})();
