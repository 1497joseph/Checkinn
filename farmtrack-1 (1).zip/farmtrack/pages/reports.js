/**
 * pages/reports.js — My Reports Page Controller
 */

const ReportsPage = (() => {
  'use strict';

  let _activeTab = 'weekly';

  const render = el => {
    el.innerHTML = `
      <div class="section-header">
        <div class="section-header__left">
          <div class="section-header__title">My Reports</div>
          <div class="section-header__sub">Generate and download your personal work reports</div>
        </div>
      </div>

      <div class="tab-pill-group mb-6">
        <button class="tab-pill ${_activeTab === 'weekly' ? 'tab-pill--active' : ''}" onclick="ReportsPage.switchTab('weekly')">📅 Weekly</button>
        <button class="tab-pill ${_activeTab === 'midmonth' ? 'tab-pill--active' : ''}" onclick="ReportsPage.switchTab('midmonth')">📆 Mid-Month (1–15)</button>
        <button class="tab-pill ${_activeTab === 'endmonth' ? 'tab-pill--active' : ''}" onclick="ReportsPage.switchTab('endmonth')">🗓 End of Month</button>
      </div>

      <!-- Weekly Tab -->
      <div id="rtab-weekly" style="display:${_activeTab === 'weekly' ? 'block' : 'none'}">
        <div class="card">
          <div class="card__header">
            <div class="card__title"><div class="icon" style="background:var(--color-primary-bg)">📅</div>Weekly Report</div>
          </div>
          <div class="card__body">
            <div class="form-row" style="align-items:flex-end">
              <div class="form-field" style="flex:1">
                <label class="form-label">Select any date within the week</label>
                <input class="form-input" type="date" id="rpt-week-date" value="${TimeUtils.today()}" />
              </div>
              <button class="btn btn--primary" onclick="ReportsPage.generateWeekly()">Generate Report</button>
            </div>
          </div>
        </div>
        <div id="rpt-weekly-result"></div>
      </div>

      <!-- Mid-Month Tab -->
      <div id="rtab-midmonth" style="display:${_activeTab === 'midmonth' ? 'block' : 'none'}">
        <div class="card">
          <div class="card__header">
            <div class="card__title"><div class="icon" style="background:var(--clr-green-50)">📆</div>Mid-Month Report (1st–15th)</div>
          </div>
          <div class="card__body">
            <div class="form-row" style="align-items:flex-end">
              <div class="form-field" style="flex:1">
                <label class="form-label">Select Month</label>
                <input class="form-input" type="month" id="rpt-mid-month" value="${TimeUtils.toMonthStr()}" />
              </div>
              <button class="btn btn--primary" onclick="ReportsPage.generateMidMonth()">Generate Report</button>
            </div>
          </div>
        </div>
        <div id="rpt-mid-result"></div>
      </div>

      <!-- End Month Tab -->
      <div id="rtab-endmonth" style="display:${_activeTab === 'endmonth' ? 'block' : 'none'}">
        <div class="card">
          <div class="card__header">
            <div class="card__title"><div class="icon" style="background:var(--clr-amber-50)">🗓</div>End-of-Month Report</div>
          </div>
          <div class="card__body">
            <div class="form-row" style="align-items:flex-end">
              <div class="form-field" style="flex:1">
                <label class="form-label">Select Month</label>
                <input class="form-input" type="month" id="rpt-end-month" value="${TimeUtils.toMonthStr()}" />
              </div>
              <button class="btn btn--primary" onclick="ReportsPage.generateEndMonth()">Generate Report</button>
            </div>
          </div>
        </div>
        <div id="rpt-end-result"></div>
      </div>
    `;
  };

  const switchTab = tab => {
    _activeTab = tab;
    ['weekly','midmonth','endmonth'].forEach(t => {
      const panel = document.getElementById(`rtab-${t}`);
      const pill  = document.querySelector(`.tab-pill[onclick="ReportsPage.switchTab('${t}')"]`);
      if (panel) panel.style.display = t === tab ? 'block' : 'none';
      if (pill)  pill.classList.toggle('tab-pill--active', t === tab);
    });
  };

  const generateWeekly = () => {
    const dateVal = document.getElementById('rpt-week-date')?.value;
    const out     = document.getElementById('rpt-weekly-result');
    if (!dateVal || !out) return;
    const { from, to } = TimeUtils.weekRange(dateVal);
    const report = ReportService.weeklyReport(AuthService.getCurrentUser().username, dateVal);
    out.innerHTML = ReportRenderer.renderUserReportHTML(report, `Weekly Report: ${TimeUtils.formatDate(from,'short')} – ${TimeUtils.formatDate(to,'short')}`);
  };

  const generateMidMonth = () => {
    const monthVal = document.getElementById('rpt-mid-month')?.value;
    const out      = document.getElementById('rpt-mid-result');
    if (!monthVal || !out) return;
    const report = ReportService.midMonthReport(AuthService.getCurrentUser().username, monthVal);
    out.innerHTML = ReportRenderer.renderUserReportHTML(report, `Mid-Month Report: ${monthVal} (1st–15th)`);
  };

  const generateEndMonth = () => {
    const monthVal = document.getElementById('rpt-end-month')?.value;
    const out      = document.getElementById('rpt-end-result');
    if (!monthVal || !out) return;
    const [y, m] = monthVal.split('-').map(Number);
    const last = TimeUtils.lastDayOfMonth(y, m);
    const report = ReportService.endMonthReport(AuthService.getCurrentUser().username, monthVal);
    out.innerHTML = ReportRenderer.renderUserReportHTML(report, `End-of-Month Report: ${monthVal} (1st–${last}th)`);
  };

  return Object.freeze({ render, switchTab, generateWeekly, generateMidMonth, generateEndMonth });
})();
