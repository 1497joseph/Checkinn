/**
 * utils/time.js — Pure Time & Date Utility Functions
 *
 * No side effects. No DOM access. No imports.
 * All functions are pure and independently testable.
 */

const TimeUtils = (() => {
  'use strict';

  /* ════════════════════════════════════
     DATE FORMATTING
  ════════════════════════════════════ */

  /** @returns {string} YYYY-MM-DD */
  const toDateStr = (d = new Date()) => {
    const date = typeof d === 'string' ? new Date(d + 'T12:00:00') : d;
    return date.toISOString().split('T')[0];
  };

  /** @returns {string} Current date as YYYY-MM-DD */
  const today = () => toDateStr();

  /** @returns {string} Current time as HH:MM */
  const nowTime = () => {
    const n = new Date();
    return `${String(n.getHours()).padStart(2,'0')}:${String(n.getMinutes()).padStart(2,'0')}`;
  };

  /** @returns {string} YYYY-MM */
  const toMonthStr = (d = new Date()) => toDateStr(d).slice(0, 7);

  /**
   * Format a YYYY-MM-DD string for human display.
   * @param {string} dateStr
   * @param {'short'|'medium'|'long'} style
   */
  const formatDate = (dateStr, style = 'medium') => {
    const d = new Date(dateStr + 'T12:00:00');
    const opts = {
      short:  { month: 'short', day: 'numeric' },
      medium: { weekday: 'short', month: 'short', day: 'numeric' },
      long:   { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' },
    };
    return d.toLocaleDateString('en-US', opts[style]);
  };

  /** @returns {string} Day name (Monday, Tuesday, ...) */
  const getDayName = dateStr =>
    new Date(dateStr + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long' });

  /** @returns {number} 0=Sun, 1=Mon, ..., 6=Sat */
  const getDayOfWeek = dateStr => new Date(dateStr + 'T12:00:00').getDay();

  /* ════════════════════════════════════
     WEEK RANGES
     Standard working week: Monday–Saturday
  ════════════════════════════════════ */

  /**
   * Get Monday–Saturday range for the week containing `date`.
   * @param {string|Date} d
   * @returns {{ from: string, to: string }}
   */
  const weekRange = (d = new Date()) => {
    const date = typeof d === 'string' ? new Date(d + 'T12:00:00') : new Date(d);
    const day  = date.getDay(); // 0=Sun
    const diffToMon = day === 0 ? -6 : 1 - day;
    const mon = new Date(date);
    mon.setDate(date.getDate() + diffToMon);
    const sat = new Date(mon);
    sat.setDate(mon.getDate() + 5);
    return { from: toDateStr(mon), to: toDateStr(sat) };
  };

  const currentWeek = () => weekRange(new Date());

  /**
   * Enumerate all Mon–Sat week ranges that overlap a given month.
   */
  const weeksInMonth = (year, month) => { // month: 1-12
    const first = new Date(year, month - 1, 1);
    const last  = new Date(year, month, 0);
    const weeks = new Set();
    let cur = new Date(first);
    while (cur <= last) {
      const { from, to } = weekRange(cur);
      weeks.add(JSON.stringify({ from, to }));
      cur.setDate(cur.getDate() + 1);
    }
    return [...weeks].map(w => JSON.parse(w));
  };

  /**
   * Get all YYYY-MM-DD dates between from and to (inclusive).
   */
  const datesBetween = (from, to) => {
    const dates = [];
    let cur = new Date(from + 'T12:00:00');
    const end = new Date(to + 'T12:00:00');
    while (cur <= end) {
      dates.push(toDateStr(cur));
      cur.setDate(cur.getDate() + 1);
    }
    return dates;
  };

  /**
   * Last day of a given month.
   * @param {number} year
   * @param {number} month 1-12
   */
  const lastDayOfMonth = (year, month) => new Date(year, month, 0).getDate();

  /* ════════════════════════════════════
     OVERTIME / HOUR CALCULATIONS
     Rules:
       - Day starts: 08:00
       - Day ends (standard): 18:00
       - Anything after 18:00 = overtime
       - Post-midnight (00:00–05:59) = late night, treated as 24h+ for calculation
       - Max standard hours/day = 10h (8am–6pm)
  ════════════════════════════════════ */

  const WORK_START_H  = 8;   // 08:00
  const WORK_END_H    = 18;  // 18:00
  const WEEK_HOURS    = 48;  // Standard 48h/week

  /**
   * Parse HH:MM string to total minutes from midnight.
   * Post-midnight hours (0–5) are treated as 24+h (i.e. still same shift).
   */
  const parseTime = timeStr => {
    if (!timeStr || timeStr === '—') return null;
    const [h, m] = timeStr.split(':').map(Number);
    if (isNaN(h) || isNaN(m)) return null;
    // Post-midnight 00:00–05:59 → treat as next calendar day, same shift
    const adjH = h < 6 ? h + 24 : h;
    return adjH * 60 + m;
  };

  /**
   * Hours worked on a given day (arrival – 08:00).
   * @param {string} arrivalHHMM
   * @returns {number} hours (float), 0 if no arrival
   */
  const hoursWorked = arrivalHHMM => {
    const arrMins = parseTime(arrivalHHMM);
    if (arrMins === null) return 0;
    const startMins = WORK_START_H * 60;
    return Math.max(0, (arrMins - startMins) / 60);
  };

  /**
   * Overtime minutes for a day (arrival – 18:00, min 0).
   * @param {string} arrivalHHMM
   * @returns {number} overtime minutes
   */
  const overtimeMinutes = arrivalHHMM => {
    const arrMins = parseTime(arrivalHHMM);
    if (arrMins === null) return 0;
    const endMins = WORK_END_H * 60;
    return Math.max(0, arrMins - endMins);
  };

  /**
   * Format minutes into "Xh Ym" display string.
   */
  const fmtMinutes = mins => {
    if (!mins || mins <= 0) return '0h 0m';
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    if (h === 0) return `${m}m`;
    if (m === 0) return `${h}h`;
    return `${h}h ${m}m`;
  };

  /**
   * Format fractional hours to "Xh Ym".
   */
  const fmtHours = hours => fmtMinutes(Math.round(hours * 60));

  /**
   * Determine week overtime (hours above 48/week) - at weekly summary level.
   */
  const weekOvertimeMinutes = totalDailyOTMins => totalDailyOTMins; // daily OT already covers it

  /* ════════════════════════════════════
     DAY NAME PARSING
  ════════════════════════════════════ */

  const DAY_NAMES = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];

  /**
   * Find most recent occurrence of a weekday by name.
   * @param {string} dayName e.g. "wednesday"
   * @returns {string} YYYY-MM-DD
   */
  const mostRecentWeekday = dayName => {
    const target = DAY_NAMES.indexOf(dayName.toLowerCase());
    if (target === -1) return today();
    const d = new Date();
    const diff = (d.getDay() - target + 7) % 7;
    d.setDate(d.getDate() - diff);
    return toDateStr(d);
  };

  /**
   * Extract day name from text (first found day word).
   */
  const extractDayName = text => {
    const lower = text.toLowerCase();
    return DAY_NAMES.find(d => lower.includes(d)) || null;
  };

  /* ════════════════════════════════════
     LIVE CLOCK
  ════════════════════════════════════ */

  /**
   * Start a live clock, calling `cb(timeStr, dateStr)` every second.
   * @returns {() => void} stop function
   */
  const startLiveClock = cb => {
    const tick = () => {
      const n = new Date();
      const timeStr = `${String(n.getHours()).padStart(2,'0')}:${String(n.getMinutes()).padStart(2,'0')}:${String(n.getSeconds()).padStart(2,'0')}`;
      const dateStr = n.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      cb(timeStr, dateStr);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  };

  return Object.freeze({
    toDateStr, today, nowTime, toMonthStr,
    formatDate, getDayName, getDayOfWeek,
    weekRange, currentWeek, weeksInMonth, datesBetween, lastDayOfMonth,
    hoursWorked, overtimeMinutes, fmtMinutes, fmtHours,
    weekOvertimeMinutes, WORK_START_H, WORK_END_H, WEEK_HOURS,
    mostRecentWeekday, extractDayName,
    startLiveClock,
  });
})();
